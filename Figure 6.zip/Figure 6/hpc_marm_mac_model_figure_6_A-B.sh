#!/bin/bash

#SBATCH --job-name=marm_mac_figure_8_A-B
#SBATCH --partition=test
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=28
#SBATCH --array=0-1500
#SBATCH --time=0:15:00
#SBATCH --mem=100GB
#SBATCH --account=COSC029486

cd "${SLURM_SUBMIT_DIR}"

echo Running on host "$(hostname)"
echo Time is "$(date)"
echo Directory is "$(pwd)"
echo Slurm job ID is "${SLURM_JOBID}"
echo This job runs on the following nodes:
echo "${SLURM_JOB_NODELIST}"
echo Running simulation with index "${SLURM_ARRAY_TASK_ID}"

module add languages/anaconda3/3.7

python hpc_marm_mac_model_figure_six_A-B.py "${SLURM_ARRAY_TASK_ID}" 0
