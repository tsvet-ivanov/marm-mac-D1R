#!/bin/bash

#SBATCH --job-name=classify
#SBATCH --partition=test
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=28
#SBATCH --time=00:15:00
#SBATCH --mem=100GB
#SBATCH --account=cosc029486

cd "${SLURM_SUBMIT_DIR}"

echo Running on host "$(hostname)"
echo Time is "$(date)"
echo Directory is "$(pwd)"
echo Slurm job ID is "${SLURM_JOBID}"
echo This job runs on the following nodes:
echo "${SLURM_JOB_NODELIST}"
echo Running simulation with index "${SLURM_ARRAY_TASK_ID}"

module add languages/anaconda3/3.7

python /user/work/nd23721/classify_hpc_marm_mac_model_figure_six_A-B.py
