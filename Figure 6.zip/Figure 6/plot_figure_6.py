import numpy as np
import matplotlib.pyplot as plt

# Load the dataset
data_path = '/Users/nd23721/Documents/marm-mac/classified_fig_6_C-D.npz'  #change to classified_fig_6_A-B.npz for plot A & B
data = np.load(data_path)

# Extract the networks from 'classified_output'
mat_mac_network_1 = data['classified_output'][0, :, :]
mat_marm_network_1 = data['classified_output'][1, :, :]

# Determine the number of D1R occupancy levels and trial types
n_occupancy_levels = mat_mac_network_1.shape[0]
n_trial_types = 4  # Assuming there are four trial types

# Initialize arrays to hold the fractions for each trial type at each D1R occupancy level
fractions_mac = np.zeros((n_occupancy_levels, n_trial_types))
fractions_marm = np.zeros((n_occupancy_levels, n_trial_types))

# Calculate the fractions for mat_mac_network_1 and mat_marm_network_1
for network, fractions in zip([mat_mac_network_1, mat_marm_network_1], [fractions_mac, fractions_marm]):
    for i in range(n_occupancy_levels):
        total_trials = network[i, :].size
        for trial_type in range(n_trial_types):
            fractions[i, trial_type] = np.sum(network[i, :] == trial_type) / total_trials

# Colors and labels for the trial types
colors = ['red', 'blue', 'silver', 'black']
labels = ['Distractor-resistant', 'Distractible', 'Transient', 'Erroneous']

# Plotting
fig, axes = plt.subplots(1, 2, figsize=(18, 6), dpi=300)

# Plot for mat_mac_network_1 and mat_marm_network_1
handles = []  # To collect the bar handles for the legend
for ax, fractions in zip(axes, [fractions_mac, fractions_marm]):
    for trial_type in range(n_trial_types):
        bar = ax.bar(np.arange(n_occupancy_levels), fractions[:, trial_type],
                     bottom=np.sum(fractions[:, :trial_type], axis=1),
                     color=colors[trial_type], label=labels[trial_type])
        if ax == axes[0]:  # Only add to handles once
            handles.append(bar)

    ax.set_xlabel('D1R occupancy', fontsize=24)
    ax.set_xticks([0, 5, 10, 15, 20])
    ax.set_xticklabels(['NO', 'LOW', 'MID', 'HIGH', 'VERY HIGH'], fontsize=15)
    ax.tick_params(axis='both', which='major', labelsize=15)

    # Add dashed lines for clarity
    for x in [0, 5, 10, 15, 20]:
        ax.axvline(x=x, color='gray', linestyle='--', linewidth=0.5)
    y_ticks = ax.get_yticks()
    for y in y_ticks:
        ax.axhline(y=y, color='gray', linestyle='--', linewidth=0.5)

axes[0].set_title('MARMOSET (MEDIUM)', fontsize=24) #change to #MACAQUE for classified_fig_6_A-B.npz
axes[0].set_ylabel('Fraction of trial outcome', fontsize=24)
axes[1].set_title('MARMOSET (EXTREME)', fontsize=24) #change to #MARMOSET (BASE) for classified_fig_6_A-B.npz

# Adjusting the legend to not overlap and only include bars
fig.legend(handles, labels, loc='upper right', bbox_to_anchor=(1, 1), title='Trial outcomes', fontsize=15, title_fontsize=15)

plt.tight_layout(pad=3.0, h_pad=1.0, w_pad=1.0, rect=[0, 0, 0.85, 1])

full_adjusted_plot_path = '/Users/nd23721/Documents/marm-mac/figure_6_C-D.png'
plt.savefig(full_adjusted_plot_path, bbox_inches='tight', dpi=300)

plt.show()
