import numpy
import brian2 as b2
from multiprocessing import Pool
import sys
import os

N_excitatory = 2048
N_inhibitory_per_pop = 256
weight_scaling_factor = 1
stimuli_width_deg = 30
stimulus_center_deg = 0
t_stimulus_start = 400 * b2.ms
t_stimuli_duration = 250 * b2.ms
sim_time = 5000. * b2.ms
distractor_center_deg = 180
t_distractor_start = 2700 * b2.ms

t_stimulus_end = t_stimulus_start + t_stimuli_duration
t_distractor_end = t_distractor_start + t_stimuli_duration

# compute the stimulus index
stim_center_idx = int(round(N_excitatory / 360. * stimulus_center_deg))
stim_width_idx = int(round(N_excitatory / 360. * stimuli_width_deg / 2))
stim_target_idx = [idx % N_excitatory
                   for idx in
                   range(stim_center_idx - stim_width_idx, stim_center_idx + stim_width_idx + 1)]

# compute the distractor index
distr_center_idx = int(round(N_excitatory / 360. * distractor_center_deg))
distr_target_idx = [idx % N_excitatory
                    for idx in
                    range(distr_center_idx - stim_width_idx, distr_center_idx + stim_width_idx + 1)]

def angle_difference(angle1, angle2):
    diff = abs(angle1 - angle2) % 360  # Difference in one direction
    return min(diff, 360 - diff)  # Shortest distance on a circle

def generate_sim_params(num_repetitions=1000):
    # Concatenating the D1R levels for Networks
    mac_network_1_D1R_levels = numpy.arange(0, 21, 1)
    marm_base_network_1_D1R_levels = numpy.arange(0, 21, 1)

    # Initialize lists to store the parameter matrices
    mac_network_1_param_matrix = []
    marm_base_network_1_param_matrix = []

    # Create parameter matrices by appending stimuli strength to each D1R level for Macaque species, Network 1
    for d1r_level in mac_network_1_D1R_levels:
        for rep in range(num_repetitions):  # Add another layer for repetitions
            param_set = numpy.array([d1r_level, rep])
            mac_network_1_param_matrix.append(param_set)

    # Create parameter matrices by appending stimuli strength to each D1R level for Marmoset species (BASE), Network 1
    for d1r_level in marm_base_network_1_D1R_levels:
        for rep in range(num_repetitions):  # Add another layer for repetitions
            param_set = numpy.array([d1r_level, rep])
            marm_base_network_1_param_matrix.append(param_set)

    # Convert the lists to a numpy array
    mac_network_1_param_matrix = numpy.array(mac_network_1_param_matrix)
    marm_base_network_1_param_matrix = numpy.array(marm_base_network_1_param_matrix)

    simulation_params = numpy.concatenate((mac_network_1_param_matrix, marm_base_network_1_param_matrix))
    num_simulations = simulation_params.shape[0]

    num_D1R_levels = 21

    # Initialise the matrices for display of results
    mat_mac_network_1 = numpy.zeros((num_D1R_levels, num_repetitions))
    mat_marm_base_network_1 = numpy.zeros((num_D1R_levels, num_repetitions))

    networks = numpy.concatenate((mat_mac_network_1, mat_marm_base_network_1))

    return mat_mac_network_1, mat_marm_base_network_1, simulation_params, num_simulations, networks

import numpy as np

def evaluate_output(spike_times_excit, spike_indices_excit, current_sim=None):
    spike_times = np.array(spike_times_excit)
    spike_indices = np.array(spike_indices_excit, dtype=int)  # Ensure indices are integers
    spikes = np.column_stack([spike_times, spike_indices])
    max_neuron_index = spike_indices.max()
    selectivity_angles = np.linspace(0, 2 * np.pi, max_neuron_index + 1, endpoint=False)

    time_window_1 = (2.2, 2.7)  # Time window from 2.2 s to 2.7 s
    time_window_2 = (4.5, 5.0)  # Time window from 4.5 s to 5.0 s
    time_window_3 = (0.2, 0.4)  # Time window from 0.2 s to 0.4 s

    def compute_population_vector(time_window, selectivity_angles, spikes):
        start_time, end_time = time_window
        spikes_in_window = spikes[(spikes[:, 0] >= start_time) & (spikes[:, 0] < end_time)]
        unique_indices, spike_counts = np.unique(spikes_in_window[:, 1], return_counts=True)
        unique_indices = unique_indices.astype(int)  # Ensure indices are integers for indexing
        full_spike_counts = np.zeros_like(selectivity_angles)
        full_spike_counts[unique_indices] = spike_counts

        P_num = np.sum(full_spike_counts * np.exp(1j * selectivity_angles))
        P_den = np.sum(full_spike_counts)
        P = P_num / P_den if P_den != 0 else 0
        C = np.abs(P)  # Modulus of the population vector
        theta_R = np.angle(P)  # Angle of the population vector
        active_neuron_count = len(unique_indices)
        total_spikes = np.sum(spike_counts)
        firing_rate = total_spikes / active_neuron_count / (end_time - start_time) if active_neuron_count > 0 else 0

        return C, (np.rad2deg(theta_R) + 360) % 360, firing_rate  # Return modulus, angle in degrees, and active neuron count

    # Compute population vectors for the defined time windows
    C_target_delay, theta_R_target_delay_deg, firing_rate_target = compute_population_vector(time_window_1, selectivity_angles, spikes)
    C_distractor_delay, theta_R_distractor_delay_deg, firing_rate_distractor = compute_population_vector(time_window_2, selectivity_angles, spikes)
    C_baseline, theta_R_baseline_deg, firing_rate_baseline = compute_population_vector(time_window_3, selectivity_angles, spikes)

    return C_target_delay, theta_R_target_delay_deg, firing_rate_target, C_distractor_delay, theta_R_distractor_delay_deg, firing_rate_distractor, C_baseline, theta_R_baseline_deg, firing_rate_baseline

error_messages = []

# Your directory with all the simulation data
data_directory = '/user/work/nd23721/marm_mac_figure_6_A-B'

# for current_sim in numpy.arange(0, 282240):
def process_simulation(current_sim):
    try:
        with numpy.load(f'{data_directory}/spike_monitor_data_simulation_{current_sim}.npz', allow_pickle=True) as data:
            spike_indices_excit = data['indices']
            spike_times_excit = data['times']

    except Exception as e:
        error_message = f"An exception occurred with file spike_monitor_data_simulation_{current_sim}.npz: {e}"
        return (error_message, 'error', current_sim,) + (numpy.nan,) * 10

    error_message = []

    C_target_delay, theta_R_target_delay_deg, firing_rate_target, \
        C_distractor_delay, theta_R_distractor_delay_deg, firing_rate_distractor, \
        C_baseline, theta_R_baseline_deg, firing_rate_baseline = evaluate_output(spike_times_excit, spike_indices_excit, current_sim)

    if current_sim <= 21000:
        return (error_message, 'mac_net_1', current_sim,
                C_target_delay, theta_R_target_delay_deg, firing_rate_target,
                C_distractor_delay, theta_R_distractor_delay_deg, firing_rate_distractor,
                C_baseline, theta_R_baseline_deg, firing_rate_baseline)
    elif 21000 < current_sim <= 42000:
        return (error_message, 'marm_base_net_1', current_sim,
                C_target_delay, theta_R_target_delay_deg, firing_rate_target,
                C_distractor_delay, theta_R_distractor_delay_deg, firing_rate_distractor,
                C_baseline, theta_R_baseline_deg, firing_rate_baseline)

if __name__ == "__main__":
    # Create a multiprocessing Pool with 28 cores
    pool = Pool()  # create a multiprocessing Pool

    # Generate simulation parameters
    mat_mac_network_1, mat_marm_base_network_1, simulation_params, num_simulations, networks = generate_sim_params(num_repetitions=1000)

    # map run_simulation to available Pool processes
    results = pool.map(process_simulation, range(num_simulations))

    error_C_target_delay_mat = numpy.empty(networks.shape, dtype=float)
    error_theta_R_target_delay_deg_mat = numpy.empty(networks.shape, dtype=float)
    error_C_distractor_delay_mat = numpy.empty(networks.shape, dtype=float)
    error_theta_R_distractor_delay_deg_mat = numpy.empty(networks.shape, dtype=float)
    error_C_baseline_mat = numpy.empty(networks.shape, dtype=float)
    error_theta_R_baseline_deg_mat = numpy.empty(networks.shape, dtype=float)
    error_firing_rate_target_mat = numpy.empty(networks.shape, dtype=float)
    error_firing_rate_distractor_mat = numpy.empty(networks.shape, dtype=float)
    error_firing_rate_baseline_mat = numpy.empty(networks.shape, dtype=float)

    mac_net_1_C_target_delay_mat = numpy.empty(networks.shape, dtype=float)
    mac_net_1_theta_R_target_delay_deg_mat = numpy.empty(networks.shape, dtype=float)
    mac_net_1_C_distractor_delay_mat = numpy.empty(networks.shape, dtype=float)
    mac_net_1_theta_R_distractor_delay_deg_mat = numpy.empty(networks.shape, dtype=float)
    mac_net_1_C_baseline_mat = numpy.empty(networks.shape, dtype=float)
    mac_net_1_theta_R_baseline_deg_mat = numpy.empty(networks.shape, dtype=float)
    mac_net_1_firing_rate_target_mat = numpy.empty(networks.shape, dtype=float)
    mac_net_1_firing_rate_distractor_mat = numpy.empty(networks.shape, dtype=float)
    mac_net_1_firing_rate_baseline_mat = numpy.empty(networks.shape, dtype=float)

    marm_base_net_1_C_target_delay_mat = numpy.empty(networks.shape, dtype=float)
    marm_base_net_1_theta_R_target_delay_deg_mat = numpy.empty(networks.shape, dtype=float)
    marm_base_net_1_C_distractor_delay_mat = numpy.empty(networks.shape, dtype=float)
    marm_base_net_1_theta_R_distractor_delay_deg_mat = numpy.empty(networks.shape, dtype=float)
    marm_base_net_1_C_baseline_mat = numpy.empty(networks.shape, dtype=float)
    marm_base_net_1_theta_R_baseline_deg_mat = numpy.empty(networks.shape, dtype=float)
    marm_base_net_1_firing_rate_target_mat = numpy.empty(networks.shape, dtype=float)
    marm_base_net_1_firing_rate_distractor_mat = numpy.empty(networks.shape, dtype=float)
    marm_base_net_1_firing_rate_baseline_mat = numpy.empty(networks.shape, dtype=float)

    # iterate through results and update the relevant matrices
    for result in results:
        error_message, half, current_sim, C_target_delay, theta_R_target_delay_deg, firing_rate_target, C_distractor_delay, theta_R_distractor_delay_deg, firing_rate_distractor, C_baseline, theta_R_baseline_deg, firing_rate_baseline = result
        if half == 'error':
            if current_sim <= 21000:
                mat_mac_network_1[
                    int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = 5 #error
            elif 21000 < current_sim <= 42000:
                mat_marm_base_network_1[
                    int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = 5 #error

            error_C_target_delay_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = C_target_delay
            error_theta_R_target_delay_deg_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = theta_R_target_delay_deg
            error_C_distractor_delay_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = C_distractor_delay
            error_theta_R_distractor_delay_deg_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = theta_R_distractor_delay_deg
            error_C_baseline_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = C_baseline
            error_theta_R_baseline_deg_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = theta_R_baseline_deg
            error_firing_rate_target_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = firing_rate_target
            error_firing_rate_distractor_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = firing_rate_distractor
            error_firing_rate_baseline_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = firing_rate_baseline

            error_messages.append(error_message)

        if half == 'mac_net_1':
            if (((not ((C_baseline > 0.5) and ((theta_R_baseline_deg <= 22.5) or (theta_R_baseline_deg >= (360 - 22.5)))))
                 and (C_target_delay > 0.5) and (C_distractor_delay > 0.5)) and ((
                                                                                         (theta_R_target_delay_deg <= 22.5) or (
                                                                                         theta_R_target_delay_deg >= (360 - 22.5))) and (
                                                                                         (theta_R_distractor_delay_deg <= 22.5) or (
                                                                                         theta_R_distractor_delay_deg >= (360 - 22.5))))):
                mat_mac_network_1[
                    int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = 0  # distractor resistant persistent activity
            elif (((not ((C_baseline > 0.5) and ((theta_R_baseline_deg <= 22.5) or (theta_R_baseline_deg >= (360 - 22.5)))))
                       and ((C_target_delay > 0.5) and (C_distractor_delay > 0.5))) and ((theta_R_target_delay_deg <= 22.5 or theta_R_target_delay_deg >= (
                        360 - 22.5)) and ((theta_R_distractor_delay_deg <= (distractor_center_deg + 22.5)) and (theta_R_distractor_delay_deg >= (distractor_center_deg - 22.5))))):
                mat_mac_network_1[
                    int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = 1  # distractible persistent activity
            elif ((C_target_delay < 0.5) and (C_distractor_delay < 0.5)) and ((firing_rate_baseline <= 10) and (firing_rate_target <= 10) and (firing_rate_distractor <= 10)):
                mat_mac_network_1[
                    int(simulation_params[current_sim, 0]), int(
                        simulation_params[current_sim, 1])] = 2  # non-persistent activity
            else:
                mat_mac_network_1[
                    int(simulation_params[current_sim, 0]), int(
                        simulation_params[current_sim, 1])] = 3  # error

            mac_net_1_C_target_delay_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = C_target_delay
            mac_net_1_theta_R_target_delay_deg_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = theta_R_target_delay_deg
            mac_net_1_C_distractor_delay_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = C_distractor_delay
            mac_net_1_theta_R_distractor_delay_deg_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = theta_R_distractor_delay_deg
            mac_net_1_C_baseline_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = C_baseline
            mac_net_1_theta_R_baseline_deg_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = theta_R_baseline_deg
            mac_net_1_firing_rate_target_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = firing_rate_target
            mac_net_1_firing_rate_distractor_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = firing_rate_distractor
            mac_net_1_firing_rate_baseline_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = firing_rate_baseline

        if half == 'marm_base_net_1':
            if (((not ((C_baseline > 0.5) and ((theta_R_baseline_deg <= 22.5) or (theta_R_baseline_deg >= (360 - 22.5)))))
                 and (C_target_delay > 0.5) and (C_distractor_delay > 0.5)) and ((
                                                                                         (theta_R_target_delay_deg <= 22.5) or (
                                                                                         theta_R_target_delay_deg >= (360 - 22.5))) and (
                                                                                         (theta_R_distractor_delay_deg <= 22.5) or (
                                                                                         theta_R_distractor_delay_deg >= (360 - 22.5))))):
                mat_marm_base_network_1[
                    int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = 0  # distractor resistant persistent activity
            elif (((not ((C_baseline > 0.5) and ((theta_R_baseline_deg <= 22.5) or (theta_R_baseline_deg >= (360 - 22.5)))))
                       and ((C_target_delay > 0.5) and (C_distractor_delay > 0.5))) and ((theta_R_target_delay_deg <= 22.5 or theta_R_target_delay_deg >= (
                                                                                                   360 - 22.5)) and (
                                                                                               (theta_R_distractor_delay_deg <= (
                                                                                                           distractor_center_deg + 22.5)) and
                                                                                               (theta_R_distractor_delay_deg >= (
                                                                                                           distractor_center_deg - 22.5))))):
                mat_marm_base_network_1[
                    int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = 1  # distractible persistent activity
            elif ((C_target_delay < 0.5) and (C_distractor_delay < 0.5)) and ((firing_rate_baseline <= 10) and (firing_rate_target <= 10) and (firing_rate_distractor <= 10)):
                mat_marm_base_network_1[
                    int(simulation_params[current_sim, 0]), int(
                        simulation_params[current_sim, 1])] = 2  # non-persistent activity
            else:
                mat_marm_base_network_1[
                    int(simulation_params[current_sim, 0]), int(
                        simulation_params[current_sim, 1])] = 3  # error

            marm_base_net_1_C_target_delay_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = C_target_delay
            marm_base_net_1_theta_R_target_delay_deg_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = theta_R_target_delay_deg
            marm_base_net_1_C_distractor_delay_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = C_distractor_delay
            marm_base_net_1_theta_R_distractor_delay_deg_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = theta_R_distractor_delay_deg
            marm_base_net_1_C_baseline_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = C_baseline
            marm_base_net_1_theta_R_baseline_deg_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = theta_R_baseline_deg
            marm_base_net_1_firing_rate_target_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = firing_rate_target
            marm_base_net_1_firing_rate_distractor_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = firing_rate_distractor
            marm_base_net_1_firing_rate_baseline_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = firing_rate_baseline

    classified_output = numpy.stack((mat_mac_network_1, mat_marm_base_network_1), axis=0)

    C_target_delay_mat = numpy.stack((mac_net_1_C_target_delay_mat, marm_base_net_1_C_target_delay_mat, error_C_target_delay_mat), axis=0)
    theta_R_target_delay_deg_mat = numpy.stack((mac_net_1_theta_R_target_delay_deg_mat, marm_base_net_1_theta_R_target_delay_deg_mat, error_theta_R_target_delay_deg_mat), axis=0)
    C_distractor_delay_mat = numpy.stack((mac_net_1_C_distractor_delay_mat, marm_base_net_1_C_distractor_delay_mat, error_C_distractor_delay_mat), axis=0)
    theta_R_distractor_delay_deg_mat = numpy.stack((mac_net_1_theta_R_distractor_delay_deg_mat, marm_base_net_1_theta_R_distractor_delay_deg_mat, error_theta_R_distractor_delay_deg_mat), axis=0)
    C_baseline_mat = numpy.stack((mac_net_1_C_baseline_mat, marm_base_net_1_C_baseline_mat, error_C_baseline_mat), axis=0)
    theta_R_baseline_deg_mat = numpy.stack((mac_net_1_theta_R_baseline_deg_mat, marm_base_net_1_theta_R_baseline_deg_mat, error_theta_R_baseline_deg_mat), axis=0)
    firing_rate_target_mat = numpy.stack((mac_net_1_firing_rate_target_mat, marm_base_net_1_firing_rate_target_mat, error_firing_rate_target_mat), axis=0)
    firing_rate_distractor_mat = numpy.stack((mac_net_1_firing_rate_distractor_mat, marm_base_net_1_firing_rate_distractor_mat, error_firing_rate_distractor_mat), axis=0)
    firing_rate_baseline_mat = numpy.stack((mac_net_1_firing_rate_baseline_mat, marm_base_net_1_firing_rate_baseline_mat, error_firing_rate_baseline_mat), axis=0)

    numpy.savez('classified_fig_6_A-B.npz',
                classified_output=classified_output,
	            error_messages=error_messages,
                C_target_delay_mat=C_target_delay_mat,
                theta_R_target_delay_deg_mat=theta_R_target_delay_deg_mat,
                C_distractor_delay_mat=C_distractor_delay_mat,
                theta_R_distractor_delay_deg_mat=theta_R_distractor_delay_deg_mat,
                C_baseline_mat=C_baseline_mat,
                theta_R_baseline_deg_mat=theta_R_baseline_deg_mat,
                firing_rate_target_mat=firing_rate_target_mat,
                firing_rate_distractor_mat=firing_rate_distractor_mat,
                firing_rate_baseline_mat=firing_rate_baseline_mat)
