import numpy
import math
import brian2 as b2
from scipy.special import erf
from numpy.fft import rfft, irfft
from brian2 import NeuronGroup, Synapses, PoissonInput, network_operation
from brian2.monitors import SpikeMonitor
from brian2 import start_scope
import sys
from multiprocessing import Pool
import os

N_excitatory = 2048
N_inhibitory_per_pop = 256
weight_scaling_factor = 1
stimuli_width_deg = 30 #20 #60
stimulus_center_deg = 0
t_stimulus_start = 400 * b2.ms #200
t_stimuli_duration = 250 * b2.ms #250
sim_time = 5000. * b2.ms #4000.
distractor_center_deg = 180
t_distractor_start = 2700 * b2.ms #2100

N_extern_poisson = 1000
poisson_firing_rate = 1.80 * b2.Hz #1.6
#poisson_firing_rate_E = 1.65 * b2.Hz #1.6

sigma_weight_profile_E2E = 14.4 #20 #18 #25 #14.4
Jpos_excit2excit = 2.1 #7.1 # 1.62 #2 #1.62 #2

sigma_weight_profile_I2E = 14.4 #20 #32 #4.5 #14.4
Jpos_inhib2excit = 1.6 #1.22 #2.2 #1.9 #1.63 #1.5 #1.4

sigma_weight_profile_E2I = 14.4 #20 #32 #25 #14.4
Jpos_excit2inhib = 1.6 #1.22 #2.2 #1.62 #1.63 #0.5

sigma_weight_profile_between_I2I = 14.4 #4.5 #14.4
Jpos_between_inhib2inhib = 2.1 #1.63 #1.5 #1.9

sigma_weight_profile_within_I2I = 14.4 #4.5 #14.4
Jpos_within_inhib2inhib = 2.1 #1 #1.63 #1.5 #1.9

monitored_subset_size_excit = 1024
monitored_subset_size_inhib = 128

def generate_sim_params():

    mac_network_1_D1R_0 = numpy.array([0.8032, -49.55, 1, 1.13, -50.00, 1])

    mac_network_1_D1R_1 = numpy.array([0.8032, -49.58, 1, 1.13, -50.00, 1])

    mac_network_1_D1R_2 = numpy.array([0.8032, -49.62, 1, 1.13, -50.00, 1])

    mac_network_1_D1R_3 = numpy.array([1.1245, -49.68, 1, 0.9, -50.00, 1])

    mac_network_1_D1R_4 = numpy.array([1.1245, -49.76, 1, 0.9, -50.00, 1])

    mac_network_1_D1R_5 = numpy.array([1.1245, -49.86, 1, 0.9, -50.00, 1])

    mac_network_1_D1R_6 = numpy.array([1.1245, -49.99, 1, 0.9, -50.00, 1])

    mac_network_1_D1R_7 = numpy.array([1.1245, -50.16, 1, 0.9, -50.00, 1])

    mac_network_1_D1R_8 = numpy.array([1.1245, -50.35, 1, 0.9, -50.00, 1])

    mac_network_1_D1R_9 = numpy.array([1.1245, -50.57, 1, 0.9, -50.00, 1])

    mac_network_1_D1R_10 = numpy.array([1.1245, -50.80, 1, 0.9, -50.00, 1])

    mac_network_1_D1R_11 = numpy.array([1.1245, -51.03, 1, 0.9, -50.00, 1])

    mac_network_1_D1R_12 = numpy.array([1.1245, -51.25, 1, 0.9, -50.00, 1])

    mac_network_1_D1R_13 = numpy.array([1.1245, -51.44, 1, 0.9, -50.00, 1])

    mac_network_1_D1R_14 = numpy.array([1.1245, -51.60, 1, 0.9, -50.00, 1])

    mac_network_1_D1R_15 = numpy.array([1.1245, -51.74, 1, 0.9, -50.00, 1])

    mac_network_1_D1R_16 = numpy.array([1.1245, -51.84, 1, 0.9, -50.00, 1])

    mac_network_1_D1R_17 = numpy.array([1.1245, -51.92, 1, 0.9, -50.00, 1])

    mac_network_1_D1R_18 = numpy.array([1.1245, -51.98, 1, 0.9, -50.00, 1])

    mac_network_1_D1R_19 = numpy.array([1.1245, -52.02, 1, 0.9, -50.00, 1])

    mac_network_1_D1R_20 = numpy.array([1.1245, -52.05, 1, 0.9, -50.00, 1])

    marm_base_network_1_D1R_0 = numpy.array([0.8032, -49.67, 1, 1.13, -50.00, 1])

    marm_base_network_1_D1R_1 = numpy.array([0.8032, -49.74, 1, 1.13, -50.00, 1])

    marm_base_network_1_D1R_2 = numpy.array([0.8032, -49.84, 1, 1.13, -50.00, 1])

    marm_base_network_1_D1R_3 = numpy.array([1.1245, -49.97, 1, 0.9, -50.00, 1])

    marm_base_network_1_D1R_4 = numpy.array([1.1245, -50.12, 1, 0.9, -50.00, 1])

    marm_base_network_1_D1R_5 = numpy.array([1.1245, -50.31, 1, 0.9, -50.00, 1])

    marm_base_network_1_D1R_6 = numpy.array([1.1245, -50.52, 1, 0.9, -50.00, 1])

    marm_base_network_1_D1R_7 = numpy.array([1.1245, -50.75, 1, 0.9, -50.00, 1])

    marm_base_network_1_D1R_8 = numpy.array([1.1245, -50.98, 1, 0.9, -50.00, 1])

    marm_base_network_1_D1R_9 = numpy.array([1.1245, -51.21, 1, 0.9, -50.00, 1])

    marm_base_network_1_D1R_10 = numpy.array([1.1245, -51.40, 1, 0.9, -50.00, 1])

    marm_base_network_1_D1R_11 = numpy.array([1.1245, -51.57, 1, 0.9, -50.00, 1])

    marm_base_network_1_D1R_12 = numpy.array([1.1245, -51.71, 1, 0.9, -50.00, 1])

    marm_base_network_1_D1R_13 = numpy.array([1.1245, -51.82, 1, 0.9, -50.00, 1])

    marm_base_network_1_D1R_14 = numpy.array([1.1245, -51.90, 1, 0.9, -50.00, 1])

    marm_base_network_1_D1R_15 = numpy.array([1.1245, -51.97, 1, 0.9, -50.00, 1])

    marm_base_network_1_D1R_16 = numpy.array([1.1245, -52.01, 1, 0.9, -50.00, 1])

    marm_base_network_1_D1R_17 = numpy.array([1.1245, -52.05, 1, 0.9, -50.00, 1])

    marm_base_network_1_D1R_18 = numpy.array([1.1245, -52.07, 1, 0.9, -50.00, 1])

    marm_base_network_1_D1R_19 = numpy.array([1.1245, -52.09, 1, 0.9, -50.00, 1])

    marm_base_network_1_D1R_20 = numpy.array([1.1245, -52.10, 1, 0.9, -50.00, 1])

    # Concatenating the D1R levels for each species and Network 1
    mac_network_1_D1R_levels = numpy.vstack([mac_network_1_D1R_0, mac_network_1_D1R_1, mac_network_1_D1R_2, mac_network_1_D1R_3,
                                          mac_network_1_D1R_4, mac_network_1_D1R_5, mac_network_1_D1R_6, mac_network_1_D1R_7,
                                             mac_network_1_D1R_8, mac_network_1_D1R_9, mac_network_1_D1R_10, mac_network_1_D1R_11,
                                             mac_network_1_D1R_12, mac_network_1_D1R_13, mac_network_1_D1R_14, mac_network_1_D1R_15,
                                             mac_network_1_D1R_16, mac_network_1_D1R_17, mac_network_1_D1R_18, mac_network_1_D1R_19,
                                             mac_network_1_D1R_20])

    marm_base_network_1_D1R_levels = numpy.vstack([marm_base_network_1_D1R_0, marm_base_network_1_D1R_1, marm_base_network_1_D1R_2, marm_base_network_1_D1R_3,
                                              marm_base_network_1_D1R_4, marm_base_network_1_D1R_5, marm_base_network_1_D1R_6, marm_base_network_1_D1R_7,
                                              marm_base_network_1_D1R_8, marm_base_network_1_D1R_9, marm_base_network_1_D1R_10, marm_base_network_1_D1R_11,
                                              marm_base_network_1_D1R_12, marm_base_network_1_D1R_13, marm_base_network_1_D1R_14, marm_base_network_1_D1R_15,
                                              marm_base_network_1_D1R_16, marm_base_network_1_D1R_17, marm_base_network_1_D1R_18, marm_base_network_1_D1R_19,
                                              marm_base_network_1_D1R_20])

    stimuli_strength_mac = 0.2
    stimuli_strength_marm_base = 0.2

    # Initialize lists to store the parameter matrices
    mac_network_1_param_matrix = []
    marm_base_network_1_param_matrix = []

    # Create parameter matrices by appending stimuli strength to each D1R level for Macaque species, Network 1
    for d1r_level in mac_network_1_D1R_levels:
        #for strength in stimuli_strength_range:
            param_set = numpy.append(d1r_level, stimuli_strength_mac)
            # Append the parameter set 1000 times
            mac_network_1_param_matrix.extend([param_set] * 1000)

    # Convert the lists to a numpy array
    mac_network_1_param_matrix = numpy.array(mac_network_1_param_matrix)

    # Create parameter matrices by appending stimuli strength to each D1R level for Marmoset species (BASE), Network 1
    for d1r_level in marm_base_network_1_D1R_levels:
        #for strength in stimuli_strength_range:
            param_set = numpy.append(d1r_level, stimuli_strength_marm_base)
            # Append the parameter set 1000 times
            marm_base_network_1_param_matrix.extend([param_set] * 1000)

    # Convert the list to a numpy array
    marm_base_network_1_param_matrix = numpy.array(marm_base_network_1_param_matrix)

    simulation_params = numpy.concatenate((mac_network_1_param_matrix, marm_base_network_1_param_matrix))

    return simulation_params

def simulate_wm(NMDA_E_scaler=1,
                NMDA_opp_tuned_I_scaler=1,
                NMDA_tuned_I_scaler=1,
                AMPA_scaler=1,
                v_firing_threshold_tuned_inhib=-50.0 * b2.mV,
                v_firing_threshold_opp_tuned_inhib=-50.0 * b2.mV,
                stimuli_strength=0.175 * b2.namp
                ):
    start_scope()  # new

    # specify the excitatory pyramidal cells:
    Cm_excit = 0.5 * b2.nF  # membrane capacitance of excitatory neurons
    G_leak_excit = 25.0 * b2.nS  # leak conductance
    E_leak_excit = -70.0 * b2.mV  # reversal potential
    v_firing_threshold_excit = -50.0 * b2.mV  # spike condition
    v_reset_excit = -60.0 * b2.mV  # reset voltage after spike
    t_abs_refract_excit = 2.0 * b2.ms  # absolute refractory period

    # specify the inhibitory interneurons:
    Cm_inhib = 0.2 * b2.nF
    G_leak_inhib = 20.0 * b2.nS
    E_leak_inhib = -70.0 * b2.mV
    v_reset_inhib = -60.0 * b2.mV
    t_abs_refract_inhib = 1.0 * b2.ms

    # specify the AMPA synapses
    E_AMPA = 0.0 * b2.mV
    tau_AMPA = 2.0 * b2.ms

    # specify the GABA synapses
    E_GABA = -70.0 * b2.mV
    tau_GABA = 10.0 * b2.ms

    # specify the NMDA synapses
    E_NMDA = 0.0 * b2.mV
    tau_NMDA_s = 100.0 * b2.ms
    tau_NMDA_x = 2.0 * b2.ms
    alpha_NMDA = 0.5 * b2.kHz

    # projections from the external population
    G_extern2inhib = 2.38 * b2.nS #2.38, 5.8 * b2.nS, 1.8
    G_extern2excit = 3.1 * b2.nS #3.1, 5.915 * b2.nS, 5

    # GABA-mediated projectsions from the inhibitory populations
    G_inhib2inhib = 1.024 * weight_scaling_factor * b2.nS #0.7413/1.25, 2.2, 1.024
    G_inhib2excit = 1.336 * weight_scaling_factor * b2.nS #0.9163/1.25, 3.9, 1.336

    # NMDA-mediated projections from the excitatory population
    G_excit2excit = 0.274 * NMDA_E_scaler * weight_scaling_factor * b2.nS #0.42, 1.05, 0.274
    G_excit2tuned_inhib = 0.212 * NMDA_tuned_I_scaler * weight_scaling_factor * b2.nS #0.49/1.25, 0.95, 0.212
    G_excit2opp_tuned_inhib = 0.212 * NMDA_opp_tuned_I_scaler * weight_scaling_factor * b2.nS #0.49/1.25, 0.95, 0.212

    # recurrent AMPA
    G_excit2excitA = 0.251 * AMPA_scaler * weight_scaling_factor * b2.nS #0.251 0.1 # why is the 1. from Stein 2020 here? 0.07
    GEEA = G_excit2excitA / G_extern2excit

    G_excit2inhibA = 0.192 * AMPA_scaler * weight_scaling_factor * b2.nS #0.192/1.25, 0.36, 0.192
    GEIA = G_excit2inhibA / G_extern2inhib

    t_stimulus_end = t_stimulus_start + t_stimuli_duration
    t_distractor_end = t_distractor_start + t_stimuli_duration

    # compute the stimulus index
    stim_center_idx = int(round(N_excitatory / 360. * stimulus_center_deg))
    stim_width_idx = int(round(N_excitatory / 360. * stimuli_width_deg / 2))
    stim_target_idx = [idx % N_excitatory
                       for idx in
                       range(stim_center_idx - stim_width_idx, stim_center_idx + stim_width_idx + 1)]

    # compute the distractor index
    distr_center_idx = int(round(N_excitatory / 360. * distractor_center_deg))
    distr_target_idx = [idx % N_excitatory
                        for idx in
                        range(distr_center_idx - stim_width_idx, distr_center_idx + stim_width_idx + 1)]

    # precompute/specify the weight profile for/in the recurrent EXCITATORY population
    tmp_excit2excit = math.sqrt(2. * math.pi) * sigma_weight_profile_E2E * erf(
        180. / math.sqrt(2.) / sigma_weight_profile_E2E) / 360.
    Jneg_excit2excit = (1. - Jpos_excit2excit * tmp_excit2excit) / (1. - tmp_excit2excit)
    presyn_excit2excit_weight_kernel = \
        [(Jneg_excit2excit + (Jpos_excit2excit - Jneg_excit2excit) *
          math.exp(-.5 * ((360. * min(j, N_excitatory - j) / N_excitatory) ** 2) / sigma_weight_profile_E2E ** 2))
         for j in range(N_excitatory)]

    # remove E-E autapses
    presyn_excit2excit_weight_kernel[0] = 0

    fft_presyn_excit2excit_weight_kernel = rfft(presyn_excit2excit_weight_kernel)

    # precompute the weight profile for the TUNED INHIBITORY recurrent population
    tmp_tuned_inhib2excit = math.sqrt(2. * math.pi) * sigma_weight_profile_I2E * erf(
        180. / math.sqrt(2.) / sigma_weight_profile_I2E) / 360.
    Jneg_tuned_inhib2excit = (1. - Jpos_inhib2excit * tmp_tuned_inhib2excit) / (1. - tmp_tuned_inhib2excit)

    # precompute the weight profile for the OPPOSITELY TUNED recurrent population
    tmp_opp_tuned_inhib2excit = math.sqrt(2. * math.pi) * sigma_weight_profile_I2E * erf(
        180. / math.sqrt(2.) / sigma_weight_profile_I2E) / 360.
    Jneg_opp_tuned_inhib2excit = (1. - Jpos_inhib2excit * tmp_opp_tuned_inhib2excit) / (1. - tmp_opp_tuned_inhib2excit)

    # precompute the weight profile for the Excitatory to INHIBITORY recurrent populations
    tmp_excit2inhib = math.sqrt(2. * math.pi) * sigma_weight_profile_E2I * erf(
        180. / math.sqrt(2.) / sigma_weight_profile_E2I) / 360.
    Jneg_excit2inhib = (1. - Jpos_excit2inhib * tmp_excit2inhib) / (1. - tmp_excit2inhib)
    presyn_excit2inhib_weight_kernel = \
        [(Jneg_excit2inhib + (Jpos_excit2inhib - Jneg_excit2inhib) *
          math.exp(-.5 * ((360. * min(j, N_excitatory - j) / N_excitatory) ** 2) / sigma_weight_profile_E2I ** 2))
         for j in range(N_excitatory)]

    fft_presyn_excit2inhib_weight_kernel = rfft(presyn_excit2inhib_weight_kernel)

    # precompute the weight profile for the tuned inhibitory to tuned inhibitory (within pops) recurrent populations
    tmp_within_tuned_inhib2tuned_inhib = math.sqrt(2. * math.pi) * sigma_weight_profile_within_I2I * erf(
        180. / math.sqrt(2.) / sigma_weight_profile_within_I2I) / 360.
    Jneg_within_tuned_inhib2tuned_inhib = (1. - Jpos_within_inhib2inhib * tmp_within_tuned_inhib2tuned_inhib) / (
                1. - tmp_within_tuned_inhib2tuned_inhib)

    # precompute the weight profile for the oppositely tuned inhibitory to oppositely tuned inhibitory (within pops) recurrent populations
    tmp_within_opp_tuned_inhib2opp_tuned_inhib = math.sqrt(2. * math.pi) * sigma_weight_profile_within_I2I * erf(
        180. / math.sqrt(2.) / sigma_weight_profile_within_I2I) / 360.
    Jneg_within_opp_tuned_inhib2opp_tuned_inhib = (
                                                              1. - Jpos_within_inhib2inhib * tmp_within_opp_tuned_inhib2opp_tuned_inhib) / (
                                                              1. - tmp_within_opp_tuned_inhib2opp_tuned_inhib)

    # precompute the weight profile for the tuned Inhibitory to opp tuned INHIBITORY (between pops) recurrent populations
    tmp_between_tuned_inhib2opp_tuned_inhib = math.sqrt(2. * math.pi) * sigma_weight_profile_between_I2I * erf(
        180. / math.sqrt(2.) / sigma_weight_profile_between_I2I) / 360.
    Jneg_between_tuned_inhib2opp_tuned_inhib = (
                                                           1. - Jpos_between_inhib2inhib * tmp_between_tuned_inhib2opp_tuned_inhib) / (
                                                           1. - tmp_between_tuned_inhib2opp_tuned_inhib)

    # precompute the weight profile for the opp tuned Inhibitory to tuned INHIBITORY (between pops) recurrent populations
    tmp_between_opp_tuned_inhib2tuned_inhib = math.sqrt(2. * math.pi) * sigma_weight_profile_between_I2I * erf(
        180. / math.sqrt(2.) / sigma_weight_profile_between_I2I) / 360.
    Jneg_between_opp_tuned_inhib2tuned_inhib = (
                                                           1. - Jpos_between_inhib2inhib * tmp_between_opp_tuned_inhib2tuned_inhib) / (
                                                           1. - tmp_between_opp_tuned_inhib2tuned_inhib)

    # define the tuned inhibitory population
    tuned_inhib_lif_dynamics = """
        s_NMDA_total : 1 # the post synaptic sum of s. compare with s_NMDA_presyn
        active : 1  # new parameter
        dv/dt = active * (
        - G_leak_inhib * (v-E_leak_inhib)
        - G_extern2inhib * s_AMPA * (v-E_AMPA)
        - G_inhib2inhib * s_GABA * (v-E_GABA)
        - G_excit2tuned_inhib * s_NMDA_total * (v-E_NMDA)/(1.0+1.0*exp(-0.062*1e3*v/volt)/3.57)
        )/Cm_inhib : volt (unless refractory)
        ds_AMPA/dt = -s_AMPA/tau_AMPA : 1
        ds_GABA/dt = -s_GABA/tau_GABA : 1
    """

    eqs_gaba = '''
    w:1
    '''

    # Tuned inhib_pop
    tuned_inhib_pop = NeuronGroup(
        N_inhibitory_per_pop, model=tuned_inhib_lif_dynamics,
        threshold="v>v_firing_threshold_tuned_inhib", reset="v=v_reset_inhib", refractory=t_abs_refract_inhib,
        method="rk2")
    # initialize with random voltages:
    tuned_inhib_pop.v = numpy.random.uniform(v_reset_inhib / b2.mV, high=v_firing_threshold_tuned_inhib / b2.mV,
                                             size=N_inhibitory_per_pop) * b2.mV

    tuned_inhib_pop.active = 1  # can remove that part while parameter search is running

    # set the connections: extern2inhib
    input_ext2tuned_inhib = PoissonInput(target=tuned_inhib_pop, target_var="s_AMPA",
                                         N=N_extern_poisson, rate=poisson_firing_rate, weight=1.0)

    # define the oppositely tuned inhibitory population
    opp_tuned_inhib_lif_dynamics = """
        s_NMDA_total : 1 # the post synaptic sum of s. compare with s_NMDA_presyn
        active : 1  # new parameter
        dv/dt = active * (
        - G_leak_inhib * (v-E_leak_inhib)
        - G_extern2inhib * s_AMPA * (v-E_AMPA)
        - G_inhib2inhib * s_GABA * (v-E_GABA)
        - G_excit2opp_tuned_inhib * s_NMDA_total * (v-E_NMDA)/(1.0+1.0*exp(-0.062*1e3*v/volt)/3.57)
        )/Cm_inhib : volt (unless refractory)
        ds_AMPA/dt = -s_AMPA/tau_AMPA : 1
        ds_GABA/dt = -s_GABA/tau_GABA : 1
    """

    # Oppositely-tuned inhib_pop
    opp_tuned_inhib_pop = NeuronGroup(
        N_inhibitory_per_pop, model=opp_tuned_inhib_lif_dynamics,
        threshold="v>v_firing_threshold_opp_tuned_inhib", reset="v=v_reset_inhib", refractory=t_abs_refract_inhib,
        method="rk2")
    # initialize with random voltages:
    opp_tuned_inhib_pop.v = numpy.random.uniform(v_reset_inhib / b2.mV, high=v_firing_threshold_opp_tuned_inhib / b2.mV,
                                                 size=N_inhibitory_per_pop) * b2.mV

    opp_tuned_inhib_pop.active = 1  # can remove that part while parameter search is running

    # set the connections: extern2inhib
    input_ext2opp_tuned_inhib = PoissonInput(target=opp_tuned_inhib_pop, target_var="s_AMPA",
                                             N=N_extern_poisson, rate=poisson_firing_rate, weight=1.0)

    # specify the excitatory population: # defined s_GABA : 1 (shared) BELOW
    excit_lif_dynamics = """
        I_stim : amp
        s_NMDA_total : 1 # the post synaptic sum of s. compare with s_NMDA_presyn
        dv/dt = (
        - G_leak_excit * (v-E_leak_excit)
        - G_extern2excit * s_AMPA * (v-E_AMPA)
        - G_inhib2excit * s_GABA * (v-E_GABA)
        - G_excit2excit * s_NMDA_total * (v-E_NMDA)/(1.0+1.0*exp(-0.062*1e3*v/volt)/3.57)
        + I_stim
        )/Cm_excit : volt (unless refractory)
        ds_AMPA/dt = -s_AMPA/tau_AMPA : 1
        ds_GABA/dt = -s_GABA/tau_GABA : 1
        ds_NMDA/dt = -s_NMDA/tau_NMDA_s + alpha_NMDA * x * (1-s_NMDA) : 1
        dx/dt = -x/tau_NMDA_x : 1
    """

    excit_pop = NeuronGroup(N_excitatory, model=excit_lif_dynamics,
                            threshold="v>v_firing_threshold_excit", reset="v=v_reset_excit; x+=1.0",
                            refractory=t_abs_refract_excit, method="rk2")

    # initialize with random voltages:
    excit_pop.v = numpy.random.uniform(v_reset_excit / b2.mV, high=v_firing_threshold_excit / b2.mV,
                                       size=N_excitatory) * b2.mV

    excit_pop.I_stim = 0. * b2.namp

    # set the connections: extern2excit
    input_ext2excit = PoissonInput(target=excit_pop, target_var="s_AMPA",
                                   N=N_extern_poisson, rate=poisson_firing_rate, weight=1.0)

    # Create synapses and set weights
    eqs_pre = '''
        s_GABA_post += w
        '''

    # define spacing between inhibitory neurons on the ring
    spacing = N_excitatory / N_inhibitory_per_pop

    # set the connections: STRUCTURED tuned inhibitory to excitatory
    syn_tuned_inhib2excit = Synapses(tuned_inhib_pop, excit_pop, eqs_gaba, on_pre=eqs_pre)
    syn_tuned_inhib2excit.connect(p=1.0)
    syn_tuned_inhib2excit.w[
        'abs((spacing * i)-j)<N_excitatory/2'] = '(Jneg_tuned_inhib2excit + (Jpos_inhib2excit - Jneg_tuned_inhib2excit) * exp(-.5 * ((360. * abs((spacing * i)-j) / N_excitatory)) ** 2 / sigma_weight_profile_I2E ** 2))'  # 'i * 0.001'
    syn_tuned_inhib2excit.w[
        'abs((spacing * i)-j)>=N_excitatory/2'] = '(Jneg_tuned_inhib2excit + (Jpos_inhib2excit - Jneg_tuned_inhib2excit) * exp(-.5 * ((360. * (N_excitatory - abs((spacing * i)-j)) / N_excitatory)) ** 2 / sigma_weight_profile_I2E ** 2))'

    # set the connections: STRUCTURED oppositely-tuned inhibitory to excitatory
    syn_opp_tuned_inhib2excit = Synapses(opp_tuned_inhib_pop, excit_pop, eqs_gaba, on_pre=eqs_pre)
    syn_opp_tuned_inhib2excit.connect(p=1.0)
    syn_opp_tuned_inhib2excit.w[
        'abs((spacing * i)-j)<N_excitatory/2'] = '(Jneg_opp_tuned_inhib2excit + (Jpos_inhib2excit - Jneg_opp_tuned_inhib2excit) * exp(-.5 * ((360. * abs(((spacing * i)-j) / N_excitatory) - 180.)) ** 2 / sigma_weight_profile_I2E ** 2))'
    syn_opp_tuned_inhib2excit.w[
        'abs((spacing * i)-j)>=N_excitatory/2'] = '(Jneg_opp_tuned_inhib2excit + (Jpos_inhib2excit - Jneg_opp_tuned_inhib2excit) * exp(-.5 * (((360. * (N_excitatory - abs((spacing * i)-j)) / N_excitatory) - 180)) ** 2 / sigma_weight_profile_I2E ** 2))'

    # set the connections: STRUCTURED tuned inhibitory to tuned inhibitory
    syn_tuned_inhib2tuned_inhib = Synapses(tuned_inhib_pop, tuned_inhib_pop, eqs_gaba, on_pre=eqs_pre,
                                           delay=0.0 * b2.ms)
    syn_tuned_inhib2tuned_inhib.connect(condition="i!=j", p=1.0)
    syn_tuned_inhib2tuned_inhib.w[
        'abs((spacing * i) - (spacing * j))<N_excitatory/2'] = '(Jneg_within_tuned_inhib2tuned_inhib + (Jpos_within_inhib2inhib - Jneg_within_tuned_inhib2tuned_inhib) * exp(-.5 * ((360. * abs((spacing * i) - (spacing * j)) / N_excitatory)) ** 2 / sigma_weight_profile_within_I2I ** 2))'
    syn_tuned_inhib2tuned_inhib.w[
        'abs((spacing * i) - (spacing * j))>=N_excitatory/2'] = '(Jneg_within_tuned_inhib2tuned_inhib + (Jpos_within_inhib2inhib - Jneg_within_tuned_inhib2tuned_inhib) * exp(-.5 * ((360. * (N_excitatory - abs((spacing * i) - (spacing * j))) / N_excitatory)) ** 2 / sigma_weight_profile_within_I2I ** 2))'

    # set the connections: STRUCTURED oppositely-tuned inhibitory to oppositely-tuned inhibitory
    syn_opp_tuned_inhib2opp_tuned_inhib = Synapses(opp_tuned_inhib_pop, opp_tuned_inhib_pop, eqs_gaba, on_pre=eqs_pre,
                                                   delay=0.0 * b2.ms)
    syn_opp_tuned_inhib2opp_tuned_inhib.connect(condition="i!=j", p=1.0)
    syn_opp_tuned_inhib2opp_tuned_inhib.w[
        'abs((spacing * i) - (spacing * j))<N_excitatory/2'] = '(Jneg_within_opp_tuned_inhib2opp_tuned_inhib + (Jpos_within_inhib2inhib - Jneg_within_opp_tuned_inhib2opp_tuned_inhib) * exp(-.5 * ((360. * abs((spacing * i) - (spacing * j)) / N_excitatory) - 180.) ** 2 / sigma_weight_profile_within_I2I ** 2))'
    syn_opp_tuned_inhib2opp_tuned_inhib.w[
        'abs((spacing * i) - (spacing * j))>=N_excitatory/2'] = '(Jneg_within_opp_tuned_inhib2opp_tuned_inhib + (Jpos_within_inhib2inhib - Jneg_within_opp_tuned_inhib2opp_tuned_inhib) * exp(-.5 * ((360. * (N_excitatory - abs((spacing * i) - (spacing * j))) / N_excitatory) - 180.) ** 2 / sigma_weight_profile_within_I2I ** 2))'

    # set the connections: STRUCTURED tuned inhibitory to oppositely-tuned inhibitory
    syn_tuned_inhib2opp_tuned_inhib = Synapses(tuned_inhib_pop, opp_tuned_inhib_pop, eqs_gaba, on_pre=eqs_pre,
                                               delay=0.0 * b2.ms)
    syn_tuned_inhib2opp_tuned_inhib.connect(p=1.0)
    syn_tuned_inhib2opp_tuned_inhib.w[
        'abs((spacing * i) - (spacing * j))<N_excitatory/2'] = '(Jneg_between_tuned_inhib2opp_tuned_inhib + (Jpos_between_inhib2inhib - Jneg_between_tuned_inhib2opp_tuned_inhib) * exp(-.5 * (((360. * abs((spacing * i) - (spacing * j)) / N_excitatory))) ** 2 / sigma_weight_profile_between_I2I ** 2))'
    syn_tuned_inhib2opp_tuned_inhib.w[
        'abs((spacing * i) - (spacing * j))>=N_excitatory/2'] = '(Jneg_between_tuned_inhib2opp_tuned_inhib + (Jpos_between_inhib2inhib - Jneg_between_tuned_inhib2opp_tuned_inhib) * exp(-.5 * (((360. * (N_excitatory - abs((spacing * i) - (spacing * j))) / N_excitatory))) ** 2 / sigma_weight_profile_between_I2I ** 2))'

    # set the connections: STRUCTURED oppositely-tuned inhibitory to tuned inhibitory
    syn_opp_tuned_inhib2tuned_inhib = Synapses(opp_tuned_inhib_pop, tuned_inhib_pop, eqs_gaba, on_pre=eqs_pre,
                                               delay=0.0 * b2.ms)
    syn_opp_tuned_inhib2tuned_inhib.connect(p=1.0)
    syn_opp_tuned_inhib2tuned_inhib.w[
        'abs((spacing * i) - (spacing * j))<N_excitatory/2'] = '(Jneg_between_opp_tuned_inhib2tuned_inhib + (Jpos_between_inhib2inhib - Jneg_between_opp_tuned_inhib2tuned_inhib) * exp(-.5 * ((360. * abs((spacing * i) - (spacing * j)) / N_excitatory) - 180.) ** 2 / sigma_weight_profile_between_I2I ** 2))'
    syn_opp_tuned_inhib2tuned_inhib.w[
        'abs((spacing * i) - (spacing * j))>=N_excitatory/2'] = '(Jneg_between_opp_tuned_inhib2tuned_inhib + (Jpos_between_inhib2inhib - Jneg_between_opp_tuned_inhib2tuned_inhib) * exp(-.5 * ((360. * (N_excitatory - abs((spacing * i) - (spacing * j))) / N_excitatory) - 180.) ** 2 / sigma_weight_profile_between_I2I ** 2))'

    # equation for presynaptic AMPA-mediated spike
    eqs_AMPA_pre = '''
     s_AMPA_post += w
     '''

    eqs_AMPA = '''
     w : 1
     '''

    syn_AMPA_excit2tuned_inhib = Synapses(excit_pop, tuned_inhib_pop, model=eqs_AMPA, on_pre=eqs_AMPA_pre)
    syn_AMPA_excit2tuned_inhib.connect(p=1.0)
    syn_AMPA_excit2tuned_inhib.w[
        'abs(i-(spacing*j))<N_excitatory/2'] = 'GEIA * (Jneg_excit2inhib + (Jpos_excit2inhib - Jneg_excit2inhib) * exp(-.5 * (360. * abs(i-(spacing*j)) / N_excitatory) ** 2 / sigma_weight_profile_E2I ** 2))'
    syn_AMPA_excit2tuned_inhib.w[
        'abs(i-(spacing*j))>=N_excitatory/2'] = 'GEIA * (Jneg_excit2inhib + (Jpos_excit2inhib - Jneg_excit2inhib) * exp(-.5 * (360. * (N_excitatory - abs(i-(spacing*j))) / N_excitatory) ** 2 / sigma_weight_profile_E2I ** 2))'

    syn_AMPA_excit2opp_tuned_inhib = Synapses(excit_pop, opp_tuned_inhib_pop, model=eqs_AMPA,
                                              on_pre=eqs_AMPA_pre)  # Synapses(excit_pop, opp_tuned_inhib_pop, 's_ampa', weight=lambda i, j: wrec_i * (Jm_ei + (Jp_ei - Jm_ei) * exp(-0.5 * (360. * min(abs(i - 4 * j), NE - abs(i - 4 * j)) / NE) ** 2 / sigma_ei ** 2)))
    syn_AMPA_excit2opp_tuned_inhib.connect(p=1.0)
    syn_AMPA_excit2opp_tuned_inhib.w[
        'abs(i-(spacing*j))<N_excitatory/2'] = 'GEIA * (Jneg_excit2inhib + (Jpos_excit2inhib - Jneg_excit2inhib) * exp(-.5 * (360. * abs(i-(spacing*j)) / N_excitatory) ** 2 / sigma_weight_profile_E2I ** 2))'
    syn_AMPA_excit2opp_tuned_inhib.w[
        'abs(i-(spacing*j))>=N_excitatory/2'] = 'GEIA * (Jneg_excit2inhib + (Jpos_excit2inhib - Jneg_excit2inhib) * exp(-.5 * (360. * (N_excitatory - abs(i-(spacing*j))) / N_excitatory) ** 2 / sigma_weight_profile_E2I ** 2))'

    syn_AMPA_excit2excit = Synapses(excit_pop, excit_pop, model=eqs_AMPA, on_pre=eqs_AMPA_pre)
    syn_AMPA_excit2excit.connect(condition="i!=j", p=1.0)
    syn_AMPA_excit2excit.w[
        'abs(i-j)<N_excitatory/2'] = 'GEEA * (Jneg_excit2excit + (Jpos_excit2excit - Jneg_excit2excit) * exp(-.5 * (360. * abs(i-j) / N_excitatory) ** 2 / sigma_weight_profile_E2E ** 2))'
    syn_AMPA_excit2excit.w[
        'abs(i-j)>=N_excitatory/2'] = 'GEEA * (Jneg_excit2excit + (Jpos_excit2excit - Jneg_excit2excit) * exp(-.5 * (360. * (N_excitatory - abs(i-j)) / N_excitatory) ** 2 / sigma_weight_profile_E2E ** 2))'

    # set the connections: STRUCTURED recurrent excitatory to excitatory and (tuned and opp-tuned) inhibitory - seems to be faster than the Synapses approach
    @network_operation()
    def update_nmda_sum():
        fft_s_NMDA = rfft(excit_pop.s_NMDA)
        fft_s_NMDA_E2E_total = numpy.multiply(fft_presyn_excit2excit_weight_kernel, fft_s_NMDA)
        fft_s_NMDA_E2I_total = numpy.multiply(fft_presyn_excit2inhib_weight_kernel, fft_s_NMDA)
        s_NMDA_tot = irfft(fft_s_NMDA_E2E_total)
        s_NMDA_EI_tot = irfft(fft_s_NMDA_E2I_total)
        excit_pop.s_NMDA_total_ = s_NMDA_tot

        # set the connections: STRUCTURED NMDA-mediated excitatory to tuned inhibitory
        tuned_inhib_pop.s_NMDA_total_ = s_NMDA_EI_tot[0: -1: int(spacing)]

        # set the connections: STRUCTURED NMDA-mediated excitatory to oppositely-tuned inhibitory
        opp_tuned_inhib_pop.s_NMDA_total = s_NMDA_EI_tot[0: -1: int(spacing)]

    @network_operation(dt=1 * b2.ms)
    def stimulate_network(t):
        if t >= t_stimulus_start and t < t_stimulus_end:
            excit_pop.I_stim[stim_target_idx] = stimuli_strength
        else:
            excit_pop.I_stim = 0. * b2.namp
        # add distractor
        if t >= t_distractor_start and t < t_distractor_end:
            excit_pop.I_stim[distr_target_idx] = stimuli_strength

    def get_monitors(pop, nr_monitored, N):
        nr_monitored = min(nr_monitored, (N))
        idx_monitored_neurons = \
            [int(math.ceil(k))
             for k in numpy.linspace(0, N - 1, nr_monitored + 2)][1:-1]
        spike_monitor = SpikeMonitor(pop, record=idx_monitored_neurons)
        return spike_monitor, idx_monitored_neurons

    # collect data of a subset of neurons: #can remove some parts of the below while parameter search is running
    spike_monitor_excit, idx_monitored_neurons_excit = \
        get_monitors(excit_pop, monitored_subset_size_excit, N_excitatory)

    b2.run(sim_time)

    spike_indices_excit = spike_monitor_excit.i[:]  # This is a NumPy array with neuron indices
    spike_times_excit = spike_monitor_excit.t[:]

    return spike_indices_excit, spike_times_excit

def getting_started(simulation_params, simulation_id):
    start_scope() #new
    # Unpack simulation_params
    NMDA_E_scaler, v_firing_threshold_tuned_inhib, NMDA_tuned_I_scaler, AMPA_excit_AND_inhib_scaler, v_firing_threshold_opp_tuned_inhib, NMDA_opp_tuned_I_scaler, stimuli_strength = simulation_params

    # Use simulation_id as the seed for reproducibility
    b2.seed(simulation_id)

    b2.defaultclock.dt = 0.1 * b2.ms
    spike_indices_excit, spike_times_excit = simulate_wm(NMDA_E_scaler=NMDA_E_scaler,
                                                         NMDA_opp_tuned_I_scaler=NMDA_opp_tuned_I_scaler,
                                                         NMDA_tuned_I_scaler=NMDA_tuned_I_scaler,
                                                         AMPA_scaler=AMPA_excit_AND_inhib_scaler,
                                                         v_firing_threshold_tuned_inhib=v_firing_threshold_tuned_inhib * b2.mV,
                                                         v_firing_threshold_opp_tuned_inhib=v_firing_threshold_opp_tuned_inhib * b2.mV,
                                                         stimuli_strength=stimuli_strength * b2.namp
                                                         )

    # add the code that reduces the data here

    filename = f'/user/work/nd23721/marm_mac_figure_6_A-B/spike_monitor_data_simulation_{simulation_id}.npz'
    numpy.savez(filename,
                indices=spike_indices_excit,
                times=spike_times_excit,
                simulation_id=simulation_id,
                simulation_params=simulation_params)

if __name__ == "__main__":
    # Get the job index from command-line arguments
    task_index = int(sys.argv[1])
    offset = int(sys.argv[2])

    # Adjust the task index
    task_index += offset

    # Generate simulation parameters
    simulation_params = generate_sim_params()

    # Each job runs 28 simulations
    start_index = task_index * 28
    end_index = min(start_index + 28, len(simulation_params))  # Here we ensure that end_index doesn't exceed the size of simulation_params

    # Create a multiprocessing Pool with 28 cores
    pool = Pool(28)

    # Assign the specific range of simulation parameters for each multiprocessing task
    param_range = [(simulation_params[i], i) for i in range(start_index, end_index)]

    # Run the simulation for each parallel job using the multiprocessing Pool
    pool.starmap(getting_started, param_range)

    # Close the Pool to free resources
    pool.close()
    pool.join()
