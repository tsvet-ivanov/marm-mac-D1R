import numpy as np
import matplotlib.pyplot as plt

# Load the dataset
file_path = '/Users/nd23721/Documents/marm-mac/scripts_final/Figure 8/classified_fig_8.npz'
data_new = np.load(file_path)

# Extract the dip_start data and classified outputs for Macaque and Marmoset
dip_start_mat = data_new['dip_start_mat']
classified_output = data_new['classified_output']

# Define the trial type for erroneous trials
erroneous_trial_type = 2

# Align the data to the first 21 levels for both species
dip_start_mac_valid = dip_start_mat[0, :21, :]
dip_start_marm_valid = dip_start_mat[1, :21, :]

# Filter out erroneous trials for each level
filtered_dip_start_mac = [
    dip_start_mac_valid[i][classified_output[0, i] != erroneous_trial_type]
    for i in range(21)
]
filtered_dip_start_marm = [
    dip_start_marm_valid[i][classified_output[1, i] != erroneous_trial_type]
    for i in range(21)
]

# Count the number of remaining trials per level, including NaN (treated as 3.4) but excluding negative adjusted values
remaining_trials_mac = [
    len([val for val in np.nan_to_num(filtered_dip_start_mac[i], nan=3.4) if val - 0.4 >= 0])
    for i in range(21)
]
remaining_trials_marm = [
    len([val for val in np.nan_to_num(filtered_dip_start_marm[i], nan=3.4) if val - 0.4 >= 0])
    for i in range(21)
]
# Replace NaN values with 3.4, exclude negative adjusted values, and calculate averages
avg_dip_start_mac_adjusted = [
    np.mean([val - 0.4 for val in np.nan_to_num(filtered_dip_start_mac[i], nan=3.4) if val - 0.4 > 0])
    if len(filtered_dip_start_mac[i]) > 0 else 0
    for i in range(21)
]

avg_dip_start_marm_adjusted_fixed = [
    np.mean([val - 0.4 for val in np.nan_to_num(filtered_dip_start_marm[i], nan=3.4) if val - 0.4 > 0])
    if len(filtered_dip_start_marm[i]) > 0 else 0
    for i in range(21)
]

# Recompute fractions for classifications
n_occupancy_levels = classified_output.shape[1]
n_trial_types = 4
fractions_mac = np.zeros((n_occupancy_levels, n_trial_types))
fractions_marm = np.zeros((n_occupancy_levels, n_trial_types))

# Update classified outputs by subtracting 0.4 and marking <0.35 as transient
updated_classified_output = np.copy(classified_output)
# for species in range(2):
#     for level in range(n_occupancy_levels):
#         fixation_durations_subtracted = dip_start_mat[species, level, :] - 0.4
#         updated_classified_output[species, level, fixation_durations_subtracted < 0.35] = 2

# Calculate fractions for Macaque and Marmoset
for i in range(n_occupancy_levels):
    total_trials_mac = updated_classified_output[0, i, :].size
    for trial_type in range(n_trial_types):
        fractions_mac[i, trial_type] = (
                np.sum(updated_classified_output[0, i, :] == trial_type) / total_trials_mac
        )

    total_trials_marm = updated_classified_output[1, i, :].size
    for trial_type in range(n_trial_types):
        fractions_marm[i, trial_type] = (
                np.sum(updated_classified_output[1, i, :] == trial_type) / total_trials_marm
        )

# Colors and labels for the trial types
colors = ['red', 'blue', 'black', 'green']
labels = ['Distractor-resistant', 'Distractible', 'Erroneous', 'Other']

# Custom x-tick labels
custom_positions = [0, 5, 10, 15, 20]
label_fraction = [0.0, 0.2, 0.4, 0.6, 0.8, 1.0]
label_duration = [0.0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0]
custom_labels = ["NO", "LOW", "MID", "HIGH", "VERY HIGH"]

# Level 11 Data (Lower Right Plot) - Convert to Seconds
level_11_mac = np.nan_to_num(dip_start_mat[0, 10], nan=3.4) * 1000 - 400
level_11_marm = np.nan_to_num(dip_start_mat[1, 10], nan=3.4) * 1000 - 400

means_adjusted = [np.mean(level_11_mac) / 1000, np.mean(level_11_marm) / 1000]
std_devs_adjusted = [np.std(level_11_mac) / 1000, np.std(level_11_marm) / 1000]
adjusted_labels = ['MACAQUE-D1R', 'MARMOSET-D1R']
bar_positions = [0.49, 0.51]

# Start Plotting
fig, axes = plt.subplots(2, 2, figsize=(15, 12), dpi=300, gridspec_kw={'width_ratios': [1, 1], 'wspace': 0.2})
axes = axes.flatten()

# Top Left: Macaque-D1R Model
for trial_type in range(n_trial_types):
    axes[0].bar(
        np.arange(n_occupancy_levels), fractions_mac[:, trial_type],
        bottom=np.sum(fractions_mac[:, :trial_type], axis=1),
        color=colors[trial_type], label=labels[trial_type]
    )
axes[0].set_title('MACAQUE-D1R MODEL', fontsize=24)
axes[0].set_xticks(custom_positions)
axes[0].set_xticklabels(custom_labels, fontsize=15)
axes[0].set_xlabel('')  # Remove x-axis title
axes[0].set_ylabel('Fraction of trial outcome', fontsize=24)
axes[0].set_yticklabels(label_fraction, fontsize=15)
axes[0].grid(axis='y', linestyle='--', alpha=0.7, color='grey', linewidth=0.5)

# Add vertical grid lines at specific positions
for pos in custom_positions:
    axes[0].axvline(pos, linestyle='--', alpha=0.7, color='grey', linewidth=0.5)

# Top Right: Marmoset-D1R Model
for trial_type in range(n_trial_types):
    axes[2].bar(
        np.arange(n_occupancy_levels), fractions_marm[:, trial_type],
        bottom=np.sum(fractions_marm[:, :trial_type], axis=1),
        color=colors[trial_type], label=labels[trial_type]
    )
axes[2].set_title('MARMOSET-D1R MODEL', fontsize=24)
axes[2].set_xlabel(r'D1R occupancy on Fixation I$_{\mathit{NEAR}}$ cells', fontsize=24)
axes[2].set_ylabel('Fraction of trial outcome', fontsize=24)
axes[2].set_xticks(custom_positions)
axes[2].set_xticklabels(custom_labels, fontsize=15)
axes[2].set_yticklabels(label_fraction, fontsize=15)
axes[2].grid(axis='y', linestyle='--', alpha=0.7, color='grey', linewidth=0.5)

# Add vertical grid lines at specific positions
for pos in custom_positions:
    axes[2].axvline(pos, linestyle='--', alpha=0.7, color='grey', linewidth=0.5)

# Bottom Left: Fixation Duration Comparison
x = np.arange(21)
axes[1].bar(x, avg_dip_start_mac_adjusted, width=0.8, color='#984EA3', alpha=1.0, edgecolor='black', label='MACAQUE-D1R')
axes[1].bar(x, avg_dip_start_marm_adjusted_fixed, width=0.8, color='#FDBF6F', alpha=0.75, edgecolor='black', label='MARMOSET-D1R')
axes[1].set_xticks(custom_positions)
axes[1].set_xticklabels(custom_labels, fontsize=15)
axes[1].set_ylim(0, 3.75)
axes[1].set_yticks([0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0])  # Custom y-tick positions without 3.5
# axes[1].set_xlabel(r'D1R occupancy on Fixation I$_{\mathit{NEAR}}$ cells', fontsize=24)
axes[1].set_ylabel('Fixation Duration (s)', fontsize=24)
axes[1].legend(loc='upper right')
axes[1].set_yticklabels(label_duration, fontsize=15)
axes[1].grid(axis='y', linestyle='--', alpha=0.7, color='grey', linewidth=0.5)

# Add vertical grid lines at specific positions
for pos in custom_positions:
    axes[1].axvline(pos, linestyle='--', alpha=0.7, color='grey', linewidth=0.5)

# Adding "n=" labels for remaining trials
for i, (count_mac, count_marm) in enumerate(zip(remaining_trials_mac, remaining_trials_marm)):
    if 0 < count_mac < 1000 and avg_dip_start_mac_adjusted[i] > 0:
        axes[1].text(x[i], 1.5, f"n = {count_mac}", ha='center', va='center', fontsize=10,
                     color='white', fontweight='bold', rotation=90)
    if 0 < count_marm < 1000 and avg_dip_start_marm_adjusted_fixed[i] > 0:
        axes[1].text(x[i], 2.5, f"n = {count_marm}", ha='center', va='center', fontsize=10,
                     color='black', fontweight='bold', rotation=90)

# Adjust levels of interest: 9, 10, 11, 12, 13 (indices 8–12)
levels_of_interest_mid = [8, 9, 10, 11, 12]

# Filter erroneous trials for levels 9–13 for both species
filtered_mac_data_9_to_13 = []
filtered_marm_data_9_to_13 = []

for level in levels_of_interest_mid:
    mac_trials = dip_start_mac_valid[level][classified_output[0, level] != erroneous_trial_type]
    marm_trials = dip_start_marm_valid[level][classified_output[1, level] != erroneous_trial_type]
    filtered_mac_data_9_to_13.extend(np.nan_to_num(mac_trials, nan=3.4) * 1000 - 400)
    filtered_marm_data_9_to_13.extend(np.nan_to_num(marm_trials, nan=3.4) * 1000 - 400)

# Convert to arrays
filtered_mac_data_9_to_13 = np.array(filtered_mac_data_9_to_13)
filtered_marm_data_9_to_13 = np.array(filtered_marm_data_9_to_13)

# Recalculate means and SDs for levels 9–13
mean_mac_9_to_13 = np.mean(filtered_mac_data_9_to_13) / 1000  # Convert to seconds
mean_marm_9_to_13 = np.mean(filtered_marm_data_9_to_13) / 1000  # Convert to seconds

std_dev_mac_9_to_13 = np.std(filtered_mac_data_9_to_13) / 1000  # Convert to seconds
std_dev_marm_9_to_13 = np.std(filtered_marm_data_9_to_13) / 1000  # Convert to seconds

# Calculate CVs for levels 9–13
cv_mac_9_to_13 = std_dev_mac_9_to_13 / mean_mac_9_to_13
cv_marm_9_to_13 = std_dev_marm_9_to_13 / mean_marm_9_to_13

# Permutation test for mean difference
np.random.seed(42) #Set a random seed for the permutation test to ensure reproducibility
observed_mean_diff_9_to_13 = mean_mac_9_to_13 - mean_marm_9_to_13
combined_data_9_to_13 = np.concatenate((filtered_mac_data_9_to_13, filtered_marm_data_9_to_13))
n_permutations = 10000
permuted_mean_diffs_9_to_13 = []

for _ in range(n_permutations):
    permuted_labels = np.random.permutation(combined_data_9_to_13)
    permuted_mac = permuted_labels[:len(filtered_mac_data_9_to_13)]
    permuted_marm = permuted_labels[len(filtered_mac_data_9_to_13):]
    permuted_mean_diffs_9_to_13.append(
        np.mean(permuted_mac) / 1000 - np.mean(permuted_marm) / 1000  # Convert back to seconds
    )

# Calculate p-value for permutation test
permuted_mean_diffs_9_to_13 = np.array(permuted_mean_diffs_9_to_13)
p_value_permutation_9_to_13 = np.mean(np.abs(permuted_mean_diffs_9_to_13) >= np.abs(observed_mean_diff_9_to_13))

# -------------------------------------------------------------------------
# Bottom‑Right PANEL  –  bar  |  violin  |  dots+box  (no overlap)
# -------------------------------------------------------------------------
import matplotlib.patches as mpatches          # only once at file‑top

axes[3].cla()                                  # fresh Axes

# 1.  THIN MEAN BARS -----------------------------------------------------
bar_positions = np.array([0, 1])
bar_width     = 0.2

axes[3].bar(bar_positions,
            [mean_mac_9_to_13, mean_marm_9_to_13],
            yerr=[std_dev_mac_9_to_13, std_dev_marm_9_to_13],
            capsize=10,
            width=bar_width,
            color=['#984EA3', '#FDBF6F'],
            edgecolor='black',
            zorder=2)

# 2.  OFFSETS FOR EACH COMPONENT ----------------------------------------
scatter_offset = bar_width + 0.08     # 0.26 → dots & box
violin_shift   = 0.12                 # violin sits 0.12 to the LEFT of dots

dot_x     = bar_positions + scatter_offset          # centre of dots / box
violin_x  = dot_x + violin_shift                    # centre of violin

# 3.  RAW DOTS -----------------------------------------------------------
rng   = np.random.default_rng(42)
xjit  = 0.1                                        # half‑range jitter

axes[3].scatter(
    dot_x[0] + rng.uniform(-xjit, xjit, size=filtered_mac_data_9_to_13.size),
    filtered_mac_data_9_to_13 / 1000,
    s=18, alpha=0.6, color='#984EA3', zorder=4)

axes[3].scatter(
    dot_x[1] + rng.uniform(-xjit, xjit, size=filtered_marm_data_9_to_13.size),
    filtered_marm_data_9_to_13 / 1000,
    s=18, alpha=0.6, color='#FDBF6F', zorder=4)

# 4.  BOX‑AND‑WHISKER ----------------------------------------------------
# box_w = 0.10
mac_s = filtered_mac_data_9_to_13  / 1000
mar_s = filtered_marm_data_9_to_13 / 1000
#
# for idx, dat in enumerate([mac_s, mar_s]):
#     axes[3].boxplot(dat,
#                     positions=[dot_x[idx]],
#                     widths=box_w,
#                     vert=True,
#                     patch_artist=True,
#                     boxprops=dict(facecolor='white', edgecolor='black'),
#                     medianprops=dict(color='black'),
#                     whiskerprops=dict(color='black'),
#                     capprops=dict(color='black'),
#                     zorder=5)

# 5.  HALF‑VIOLINS  (flat edge faces dots) -------------------------------
viol = axes[3].violinplot(
    [mac_s, mar_s],
    positions=violin_x,
    vert=True,
    showmeans=False,
    showmedians=False,
    showextrema=False,
    widths=0.50)

ylim = axes[3].get_ylim()             # y‑span for clip rectangles
for vp, colour, cx in zip(viol['bodies'],
                          ['#984EA3', '#FDBF6F'],
                          violin_x):
    vp.set_facecolor(colour)
    vp.set_alpha(0.3)
    # keep **right** half so flat side is at cx (towards dots)
    clip = mpatches.Rectangle((cx, ylim[0] - 0.25),
                              1.0, ylim[1] - ylim[0] + 0.5,
                              transform=axes[3].transData)
    vp.set_clip_path(clip)
    vp.set_zorder(1)                  # behind bar & dots

# 6.  AXIS HOUSEKEEPING --------------------------------------------------
axes[3].set_xticks(bar_positions + scatter_offset/2)   # tick midway bar–dots
axes[3].set_xticklabels(adjusted_labels, fontsize=15)
axes[3].set_ylim(0, 3.75)
axes[3].set_yticks([0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0])
axes[3].set_yticklabels(label_duration, fontsize=15)
axes[3].set_ylabel('Fixation Duration (s)', fontsize=24)

# 7.  SIGNIFICANCE LINE --------------------------------------------------
max_y_mac  = mean_mac_9_to_13  + std_dev_mac_9_to_13
max_y_marm = mean_marm_9_to_13 + std_dev_marm_9_to_13
y  = max(max_y_mac, max_y_marm) + 0.1
h  = 0.05
axes[3].plot([bar_positions[0], bar_positions[0], bar_positions[1], bar_positions[1]],
             [y, y + h, y + h, y], lw=1.5, color='black', zorder=6)

sig_txt = '***' if p_value_permutation_9_to_13 <= 0.001 else ''
axes[3].text((bar_positions[0] + bar_positions[1]) / 2, y + h,
             sig_txt, ha='center', va='bottom',
             fontsize=12, fontweight='bold', zorder=6)

# Final Layout and Show
fig.tight_layout()

# Save the figure with 300 dpi
plt.savefig('/Users/nd23721/Downloads/figure_8.png', dpi=300) #, bbox_inches='tight'

plt.show()

"""
Reproduce all statistics reported in the mid‑D1R occupancy comparison
between the marmoset‑D1R and macaque‑D1R models.

Requires:
    numpy  >= 1.20
"""

import numpy as np

# ----------------------------------------------------------------------
# 1.  FILE PATH  --------------------------------------------------------
# ----------------------------------------------------------------------
FILE_PATH = '/Users/nd23721/Documents/marm-mac/scripts_final/Figure 8/classified_fig_8.npz'

# ----------------------------------------------------------------------
# 2.  CONSTANTS  --------------------------------------------------------
# ----------------------------------------------------------------------
LEVELS_MID            = [8, 9, 10, 11, 12]   # occupancy indices
ERRONEOUS_TRIAL_CODE  = 2
N_PERMUTATIONS        = 10_000
N_BOOTSTRAP           = 10_000
RNG                   = np.random.default_rng(seed=42)   # reproducibility

# ----------------------------------------------------------------------
# 3.  LOAD DATA  --------------------------------------------------------
# ----------------------------------------------------------------------
data            = np.load(FILE_PATH)
dip_start_mat   = data['dip_start_mat']          # shape (2, 21, ~1000)
classified_out  = data['classified_output']      # labels: 0,1,3,4,5

# ----------------------------------------------------------------------
# 4.  HELPER FUNCTIONS  -------------------------------------------------
# ----------------------------------------------------------------------
def fixation_durations(species_index: int) -> np.ndarray:
    """Return fixation durations (sec) for a given species over LEVELS_MID.
       NaNs → 3.4 s sentinel; subtract 0.4 s baseline; exclude negatives."""
    durations = []
    for lvl in LEVELS_MID:
        raw = dip_start_mat[species_index, lvl]
        good = raw[classified_out[species_index, lvl] != ERRONEOUS_TRIAL_CODE]
        dur = np.nan_to_num(good, nan=3.4) - 0.4
        durations.extend(dur[dur > 0])
    return np.array(durations)

def coefficient_of_variation(arr: np.ndarray) -> float:
    return arr.std(ddof=1) / arr.mean()

def pooled_sd(a: np.ndarray, b: np.ndarray) -> float:
    na, nb = a.size, b.size
    return np.sqrt(((na-1)*a.var(ddof=1) + (nb-1)*b.var(ddof=1)) / (na+nb-2))

# ----------------------------------------------------------------------
# 5.  EXTRACT DURATIONS  ------------------------------------------------
# ----------------------------------------------------------------------
mac_dur  = fixation_durations(0)   # macaque model
marm_dur = fixation_durations(1)   # marmoset model

n_mac, n_marm = mac_dur.size, marm_dur.size
mean_mac, mean_marm = mac_dur.mean(), marm_dur.mean()
sd_mac, sd_marm     = mac_dur.std(ddof=1), marm_dur.std(ddof=1)

# ----------------------------------------------------------------------
# 6.  PERMUTATION TEST: MEAN DIFFERENCE  -------------------------------
# ----------------------------------------------------------------------
obs_mean_diff = mean_mac - mean_marm
perm_diffs = np.empty(N_PERMUTATIONS)
combined   = np.concatenate((mac_dur, marm_dur))

for i in range(N_PERMUTATIONS):
    perm   = RNG.permutation(combined)
    perm_diffs[i] = perm[:n_mac].mean() - perm[n_mac:].mean()

p_mean = (np.abs(perm_diffs) >= np.abs(obs_mean_diff)).mean()

# ----------------------------------------------------------------------
# 7.  BOOTSTRAP CI: MEAN DIFFERENCE & HEDGE'S g  -----------------------
# ----------------------------------------------------------------------
boot_mean_diff = np.empty(N_BOOTSTRAP)
boot_g         = np.empty(N_BOOTSTRAP)
J = 1 - (3 / (4*(n_mac + n_marm) - 9))           # Hedge's correction

for i in range(N_BOOTSTRAP):
    mac_samp  = RNG.choice(mac_dur,  size=n_mac,  replace=True)
    marm_samp = RNG.choice(marm_dur, size=n_marm, replace=True)
    mdiff = mac_samp.mean() - marm_samp.mean()
    psd   = pooled_sd(mac_samp, marm_samp)
    g_val = (mdiff / psd) * J
    boot_mean_diff[i] = mdiff
    boot_g[i]         = g_val

ci_mean_diff = np.percentile(boot_mean_diff, [2.5, 97.5])
ci_g         = np.percentile(boot_g,         [2.5, 97.5])

# observed Hedge's g on full data
g_obs = (obs_mean_diff / pooled_sd(mac_dur, marm_dur)) * J

# ----------------------------------------------------------------------
# 8.  COEFFICIENTS OF VARIATION  ---------------------------------------
# ----------------------------------------------------------------------
cv_mac  = coefficient_of_variation(mac_dur)
cv_marm = coefficient_of_variation(marm_dur)
obs_cv_diff = cv_mac - cv_marm

# permutation test for CV difference
perm_cv_diffs = np.empty(N_PERMUTATIONS)
for i in range(N_PERMUTATIONS):
    perm = RNG.permutation(combined)
    cv_mac_p  = coefficient_of_variation(perm[:n_mac])
    cv_marm_p = coefficient_of_variation(perm[n_mac:])
    perm_cv_diffs[i] = cv_mac_p - cv_marm_p

p_cv = (np.abs(perm_cv_diffs) >= np.abs(obs_cv_diff)).mean()

# bootstrap CI for CV difference
boot_cv_diff = np.empty(N_BOOTSTRAP)
for i in range(N_BOOTSTRAP):
    mac_samp  = RNG.choice(mac_dur,  size=n_mac,  replace=True)
    marm_samp = RNG.choice(marm_dur, size=n_marm, replace=True)
    boot_cv_diff[i] = (coefficient_of_variation(mac_samp) -
                       coefficient_of_variation(marm_samp))
ci_cv_diff = np.percentile(boot_cv_diff, [2.5, 97.5])

# ----------------------------------------------------------------------
# 9.  PRINT RESULTS  ----------------------------------------------------
# ----------------------------------------------------------------------
print("=== DESCRIPTIVE STATISTICS (mid D1R occupancy) ===")
print(f"Macaque:   n = {n_mac},  Mean = {mean_mac:.4f} s, SD = {sd_mac:.4f} s, CV = {cv_mac:.4f}")
print(f"Marmoset:  n = {n_marm}, Mean = {mean_marm:.4f} s, SD = {sd_marm:.4f} s, CV = {cv_marm:.4f}")
print()

print("=== MEAN DIFFERENCE ===")
print(f"Observed mean difference (Mac − Marm) = {obs_mean_diff:.4f} s")
print(f"Two‑sided permutation p = {p_mean:.5f}   (iterations = {N_PERMUTATIONS})")
print(f"95% bootstrap CI for mean difference = [{ci_mean_diff[0]:.4f}, {ci_mean_diff[1]:.4f}] s")
print()

print("=== HEDGE'S g (bias‑corrected Cohen's d) ===")
print(f"Hedge's g = {g_obs:.4f}")
print(f"95% bootstrap CI for g = [{ci_g[0]:.4f}, {ci_g[1]:.4f}]")
print()

print("=== COEFFICIENT‑OF‑VARIATION DIFFERENCE ===")
print(f"Observed ΔCV (Mac − Marm) = {obs_cv_diff:.4f}")
print(f"Two‑sided permutation p = {p_cv:.5f}   (iterations = {N_PERMUTATIONS})")
print(f"95% bootstrap CI for ΔCV = [{ci_cv_diff[0]:.4f}, {ci_cv_diff[1]:.4f}]")