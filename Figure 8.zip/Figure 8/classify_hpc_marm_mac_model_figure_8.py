import numpy
import brian2 as b2
from multiprocessing import Pool

def generate_sim_params(num_repetitions=1000):
    # Concatenating the D1R levels for Networks
    mac_network_1_D1R_levels = numpy.arange(0, 21, 1)

    marm_network_1_D1R_levels = numpy.arange(0, 21, 1)

    # Initialize lists to store the parameter matrices
    mac_network_1_param_matrix = []
    marm_network_1_param_matrix = []

    # Create parameter matrices by appending stimuli strength to each D1R level for Macaque species, Network 1
    for d1r_level in mac_network_1_D1R_levels:
        for rep in range(num_repetitions):  # Add another layer for repetitions
            param_set = numpy.array([d1r_level, rep])
            mac_network_1_param_matrix.append(param_set)

    # Create parameter matrices by appending stimuli strength to each D1R level for Marmoset species, Network 1
    for d1r_level in marm_network_1_D1R_levels:
        for rep in range(num_repetitions):  # Add another layer for repetitions
            param_set = numpy.array([d1r_level, rep])
            marm_network_1_param_matrix.append(param_set)

    # Convert the lists to a numpy array
    mac_network_1_param_matrix = numpy.array(mac_network_1_param_matrix)
    marm_network_1_param_matrix = numpy.array(marm_network_1_param_matrix)

    simulation_params = numpy.concatenate((mac_network_1_param_matrix, marm_network_1_param_matrix))
    num_simulations = simulation_params.shape[0]
    num_D1R_levels = 21

    # Initialise the matrices for display of results
    mat_mac_network_1 = numpy.zeros((num_D1R_levels, num_repetitions))
    mat_marm_network_1 = numpy.zeros((num_D1R_levels, num_repetitions))

    networks = numpy.concatenate((mat_mac_network_1, mat_marm_network_1))

    return mat_mac_network_1, mat_marm_network_1, simulation_params, num_simulations, networks

def evaluate_output(spike_times_fix_excit, spike_indices_fix_excit, current_sim=None):
    # Extract spike times and neuron indices
    spike_fix_times = spike_times_fix_excit  # spike times in seconds
    spike_fix_indices = spike_indices_fix_excit  # neuron indices

    # Define the parameters for the computation
    num_neurons = len(numpy.unique(spike_fix_indices))  # total number of neurons
    adjustment_val = 0.001  # small adjustment to the max time for binning
    bins_time = numpy.linspace(spike_fix_times.min(), spike_fix_times.max() + adjustment_val, 100)
    bins_neuron = numpy.linspace(0, num_neurons, 100)

    # Calculate 2D histogram for time and neurons
    counts, _, _ = numpy.histogram2d(spike_fix_times, spike_fix_indices, bins=[bins_time, bins_neuron])

    # Convert counts to spikes per second per neuron
    time_bin_duration = bins_time[1] - bins_time[0]  # duration of each time bin
    neurons_per_bin = num_neurons / 100  # number of neurons in each neuron bin
    counts_per_second_per_neuron = counts / (time_bin_duration * neurons_per_bin)

    # Average firing rate across all neurons
    average_firing_rate = counts_per_second_per_neuron.mean(axis=1)

    # Convert time bins to centers for plotting
    time_centers = bins_time[:-1] + time_bin_duration / 2

    # Define the time windows
    time_window_1 = (0.4, 0.6)
    time_window_2 = (0.6, 3.4)
    time_window_3 = (0.2, 0.4)

    # Calculate average firing rate for each time window
    mask_1 = (time_centers >= time_window_1[0]) & (time_centers <= time_window_1[1])
    mask_2 = (time_centers >= time_window_2[0]) & (time_centers <= time_window_2[1])
    mask_3 = (time_centers >= time_window_3[0]) & (time_centers <= time_window_3[1])

    firing_rate_fixation_only = average_firing_rate[mask_1].mean()
    firing_rate_fixation_dist = average_firing_rate[mask_2].mean()
    firing_rate_baseline = average_firing_rate[mask_3].mean()

    dip_start = None
    dip_end = None
    dip_duration = None
    for time, rate in zip(time_centers, average_firing_rate):
        if 0.6 <= time <= 3.4:  # Consider only the relevant time range
            if rate < 10:
                if dip_start is None:  # Start of the first dip
                    dip_start = time
            elif dip_start is not None:  # End of the first dip
                dip_end = time
                dip_duration = (dip_end - dip_start) * 1000
                break  # Stop after finding the first dip

    # Determine if there was a dip below 10 Hz
    dip_below_10hz_binary = "yes" if dip_start is not None else "no"

    return firing_rate_fixation_only, firing_rate_fixation_dist, firing_rate_baseline, dip_start, dip_end, dip_duration, dip_below_10hz_binary

error_messages = []

# Your directory with all the simulation data
data_directory = '/user/work/nd23721/marm_mac_figure_8'

# for current_sim in numpy.arange(0, 282240):
def process_simulation(current_sim):
    try:
        with numpy.load(f'{data_directory}/spike_monitor_data_simulation_{current_sim}.npz', allow_pickle=True) as data:
            spike_indices_fix_excit = data['fix_indices']
            spike_times_fix_excit = data['fix_times']

    except Exception as e:
        error_message = f"An exception occurred with file spike_monitor_data_simulation_{current_sim}.npz: {e}"
        return (error_message, 'error', current_sim,) + (numpy.nan,) * 10

    error_message = []

    firing_rate_fixation_only, firing_rate_fixation_dist, firing_rate_baseline, dip_start, dip_end, dip_duration, dip_below_10hz_binary = evaluate_output(spike_times_fix_excit, spike_indices_fix_excit, current_sim)

    if current_sim <= 21000:
        return (error_message, 'mac_net_1', current_sim,
                firing_rate_fixation_only, firing_rate_fixation_dist, firing_rate_baseline, dip_start, dip_end, dip_duration, dip_below_10hz_binary)
    elif 21000 < current_sim <= 42000:
        return (error_message, 'marm_net_1', current_sim,
                firing_rate_fixation_only, firing_rate_fixation_dist, firing_rate_baseline, dip_start, dip_end, dip_duration, dip_below_10hz_binary)

if __name__ == "__main__":
    pool = Pool()  # create a multiprocessing Pool

    # Generate simulation parameters
    mat_mac_network_1, mat_marm_network_1, simulation_params, num_simulations, networks = generate_sim_params(num_repetitions=1000)

    # map run_simulation to available Pool processes
    results = pool.map(process_simulation, range(num_simulations))

    error_firing_rate_fixation_only_mat = numpy.empty(networks.shape, dtype=float)
    error_firing_rate_fixation_dist_mat = numpy.empty(networks.shape, dtype=float)
    error_firing_rate_baseline_mat = numpy.empty(networks.shape, dtype=float)
    error_dip_start_mat = numpy.empty(networks.shape, dtype=float)
    error_dip_end_mat = numpy.empty(networks.shape, dtype=float)
    error_dip_duration_mat = numpy.empty(networks.shape, dtype=float)
    error_dip_below_10hz_binary_mat = numpy.empty(networks.shape, dtype=float)

    mac_net_1_firing_rate_fixation_only_mat = numpy.empty(networks.shape, dtype=float)
    mac_net_1_firing_rate_fixation_dist_mat = numpy.empty(networks.shape, dtype=float)
    mac_net_1_firing_rate_baseline_mat = numpy.empty(networks.shape, dtype=float)
    mac_net_1_dip_start_mat = numpy.empty(networks.shape, dtype=float)
    mac_net_1_dip_end_mat = numpy.empty(networks.shape, dtype=float)
    mac_net_1_dip_duration_mat = numpy.empty(networks.shape, dtype=float)
    mac_net_1_dip_below_10hz_binary_mat = numpy.empty(networks.shape, dtype=float)

    marm_net_1_firing_rate_fixation_only_mat = numpy.empty(networks.shape, dtype=float)
    marm_net_1_firing_rate_fixation_dist_mat = numpy.empty(networks.shape, dtype=float)
    marm_net_1_firing_rate_baseline_mat = numpy.empty(networks.shape, dtype=float)
    marm_net_1_dip_start_mat = numpy.empty(networks.shape, dtype=float)
    marm_net_1_dip_end_mat = numpy.empty(networks.shape, dtype=float)
    marm_net_1_dip_duration_mat = numpy.empty(networks.shape, dtype=float)
    marm_net_1_dip_below_10hz_binary_mat = numpy.empty(networks.shape, dtype=float)

    # iterate through results and update the relevant matrices
    for result in results:
        error_message, half, current_sim, firing_rate_fixation_only, firing_rate_fixation_dist, firing_rate_baseline, dip_start, dip_end, dip_duration, dip_below_10hz_binary = result

        if dip_below_10hz_binary == 'no':
            dip_below_10hz_binary_number = 0
        elif dip_below_10hz_binary == 'yes':
            dip_below_10hz_binary_number = 1

        if half == 'error':
            if current_sim <= 21000:
                mat_mac_network_1[
                    int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = 4 #error
            elif 21000 < current_sim <= 42000:
                mat_marm_network_1[
                    int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = 4 #error

            error_firing_rate_fixation_only_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = firing_rate_fixation_only
            error_firing_rate_fixation_dist_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = firing_rate_fixation_dist
            error_firing_rate_baseline_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = firing_rate_baseline
            error_dip_start_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = dip_start
            error_dip_end_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = dip_end
            error_dip_duration_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = dip_duration
            error_dip_below_10hz_binary_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = dip_below_10hz_binary_number

            error_messages.append(error_message)

        if half == 'mac_net_1':
            if ((firing_rate_baseline <= 10) and (firing_rate_fixation_only > 10) and (firing_rate_fixation_dist > 10) and (dip_below_10hz_binary == 'no')):
                mat_mac_network_1[
                    int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = 0  # distractor-resistant persistent fixation activity (realistic)
            elif ((firing_rate_baseline <= 10) and (firing_rate_fixation_only > 10) and (dip_below_10hz_binary == 'yes')):
                mat_mac_network_1[
                    int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = 1  # distractible persistent fixation activity (realistic)
            elif (firing_rate_baseline > 10):
                mat_mac_network_1[
                    int(simulation_params[current_sim, 0]), int(
                        simulation_params[current_sim, 1])] = 2 # erroneous during baseline or runaway activity
            else:
                mat_mac_network_1[
                    int(simulation_params[current_sim, 0]), int(
                        simulation_params[current_sim, 1])] = 3  # other

            mac_net_1_firing_rate_fixation_only_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = firing_rate_fixation_only
            mac_net_1_firing_rate_fixation_dist_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = firing_rate_fixation_dist
            mac_net_1_firing_rate_baseline_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = firing_rate_baseline
            mac_net_1_dip_start_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = dip_start
            mac_net_1_dip_end_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = dip_end
            mac_net_1_dip_duration_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = dip_duration
            mac_net_1_dip_below_10hz_binary_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = dip_below_10hz_binary_number

        if half == 'marm_net_1':
            if ((firing_rate_baseline <= 10) and (firing_rate_fixation_only > 10) and (firing_rate_fixation_dist > 10) and (dip_below_10hz_binary == 'no')):
                mat_marm_network_1[
                    int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = 0  # distractor-resistant persistent fixation activity (realistic)
            elif ((firing_rate_baseline <= 10) and (firing_rate_fixation_only > 10) and (dip_below_10hz_binary == 'yes')):
                mat_marm_network_1[
                    int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = 1  # distractible persistent fixation activity (realistic)
            elif (firing_rate_baseline > 10):
                mat_marm_network_1[
                    int(simulation_params[current_sim, 0]), int(
                        simulation_params[current_sim, 1])] = 2 # erroneous during baseline or runaway activity
            else:
                mat_marm_network_1[
                    int(simulation_params[current_sim, 0]), int(
                        simulation_params[current_sim, 1])] = 3  # other

            marm_net_1_firing_rate_fixation_only_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = firing_rate_fixation_only
            marm_net_1_firing_rate_fixation_dist_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = firing_rate_fixation_dist
            marm_net_1_firing_rate_baseline_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = firing_rate_baseline
            marm_net_1_dip_start_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = dip_start
            marm_net_1_dip_end_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = dip_end
            marm_net_1_dip_duration_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = dip_duration
            marm_net_1_dip_below_10hz_binary_mat[int(simulation_params[current_sim, 0]), int(simulation_params[current_sim, 1])] = dip_below_10hz_binary_number

    classified_output = numpy.stack((mat_mac_network_1, mat_marm_network_1), axis=0)

    firing_rate_fixation_only_mat = numpy.stack((mac_net_1_firing_rate_fixation_only_mat, marm_net_1_firing_rate_fixation_only_mat, error_firing_rate_fixation_only_mat), axis=0)
    firing_rate_fixation_dist_mat = numpy.stack((mac_net_1_firing_rate_fixation_dist_mat, marm_net_1_firing_rate_fixation_dist_mat, error_firing_rate_fixation_dist_mat), axis=0)
    firing_rate_baseline_mat = numpy.stack((mac_net_1_firing_rate_baseline_mat, marm_net_1_firing_rate_baseline_mat, error_firing_rate_baseline_mat), axis=0)
    dip_start_mat = numpy.stack((mac_net_1_dip_start_mat, marm_net_1_dip_start_mat, error_dip_start_mat), axis=0)
    dip_end_mat = numpy.stack((mac_net_1_dip_end_mat, marm_net_1_dip_end_mat, error_dip_end_mat), axis=0)
    dip_duration_mat = numpy.stack((mac_net_1_dip_duration_mat, marm_net_1_dip_duration_mat, error_dip_duration_mat), axis=0)
    dip_below_10hz_binary_mat = numpy.stack((mac_net_1_dip_below_10hz_binary_mat, marm_net_1_dip_below_10hz_binary_mat, error_dip_below_10hz_binary_mat), axis=0)

    numpy.savez('classified_fig_8.npz',
                classified_output=classified_output,
	            error_messages=error_messages,
                firing_rate_fixation_only_mat=firing_rate_fixation_only_mat,
                firing_rate_fixation_dist_mat=firing_rate_fixation_dist_mat,
                firing_rate_baseline_mat=firing_rate_baseline_mat,
                dip_start_mat=dip_start_mat,
                dip_end_mat=dip_end_mat,
                dip_duration_mat=dip_duration_mat,
                dip_below_10hz_binary_mat=dip_below_10hz_binary_mat)