#!/bin/bash

#SBATCH --job-name=fix_model
#SBATCH --partition=test
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=28
#SBATCH --array=0-1500
#SBATCH --time=0:25:00
#SBATCH --mem=100GB
#SBATCH --account=COSC029486

cd "${SLURM_SUBMIT_DIR}"

echo Running on host "$(hostname)"
echo Time is "$(date)"
echo Directory is "$(pwd)"
echo Slurm job ID is "${SLURM_JOBID}"
echo This job runs on the following nodes:
echo "${SLURM_JOB_NODELIST}"
echo Running simulation with index "${SLURM_ARRAY_TASK_ID}"

module add languages/python/3.12.3

python hpc_model_marm_mac_fixation_model_1000_reps_trial_autapses_cleaned.py "${SLURM_ARRAY_TASK_ID}" 0

