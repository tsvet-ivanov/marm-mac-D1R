import numpy
import math
import brian2 as b2
from scipy.special import erf
from numpy.fft import rfft, irfft
from brian2 import NeuronGroup, Synapses, PoissonInput, network_operation
from brian2.monitors import SpikeMonitor
from brian2 import start_scope
import sys
from pathos.multiprocessing import ProcessingPool as Pool  # Import pathos pool

#new
import multiprocess as mp
#new

import os
import dill

from brian2 import prefs
prefs.codegen.target = "numpy"

#new
# Ensure compatibility with dill for serialization
mp.context._force_start_method('fork')  # Correct method for POSIX systems

def wrapper(args):
    params, index = args
    # Extract the single value from the NumPy array, if necessary
    v_firing_threshold_fix_tuned_inhib = params[0]
    print(f"Starting simulation for index {index} with params {params}...")
    return getting_started(v_firing_threshold_fix_tuned_inhib, index)

#new

N_excitatory = 2048
N_inhibitory_per_pop = 512
N_fix_excitatory = 256
N_fix_inhibitory_per_pop = 32 #64
weight_scaling_factor = 1
stimuli_width_deg = 30
t_fixation_start = 400 * b2.ms
angles = [0, 45, 90, 135, 180, 225, 270, 315]
sim_time = 3400. * b2.ms

num_stimuli = 175  # Number of stimuli

t_distractor_start = 600 * b2.ms
t_distractor_duration = 16 * b2.ms

# Compute indices corresponding to the random angles and their time windows
stim_width_idx = int(round(N_excitatory / 360. * stimuli_width_deg / 2))

N_extern_poisson = 1000
poisson_firing_rate = 1.80 * b2.Hz

sigma_weight_profile_E2E = 14.4
Jpos_excit2excit = 2.1

sigma_weight_profile_I2E = 14.4
Jpos_inhib2excit = 1.6

sigma_weight_profile_E2I = 14.4
Jpos_excit2inhib = 1.6

sigma_weight_profile_between_I2I = 14.4
Jpos_between_inhib2inhib = 2.1

sigma_weight_profile_within_I2I = 14.4
Jpos_within_inhib2inhib = 2.1

monitored_subset_size_excit = 1024
monitored_subset_size_inhib = 128

def generate_sim_params():

    mac_network_1_D1R_0 = numpy.array([-49.55])

    mac_network_1_D1R_1 = numpy.array([-49.58])

    mac_network_1_D1R_2 = numpy.array([-49.62])

    mac_network_1_D1R_3 = numpy.array([-49.68])

    mac_network_1_D1R_4 = numpy.array([-49.76])

    mac_network_1_D1R_5 = numpy.array([-49.86])

    mac_network_1_D1R_6 = numpy.array([-49.99])

    mac_network_1_D1R_7 = numpy.array([-50.16])

    mac_network_1_D1R_8 = numpy.array([-50.35])

    mac_network_1_D1R_9 = numpy.array([-50.57])

    mac_network_1_D1R_10 = numpy.array([-50.80])

    mac_network_1_D1R_11 = numpy.array([-51.03])

    mac_network_1_D1R_12 = numpy.array([-51.25])

    mac_network_1_D1R_13 = numpy.array([-51.44])

    mac_network_1_D1R_14 = numpy.array([-51.60])

    mac_network_1_D1R_15 = numpy.array([-51.74])

    mac_network_1_D1R_16 = numpy.array([-51.84])

    mac_network_1_D1R_17 = numpy.array([-51.92])

    mac_network_1_D1R_18 = numpy.array([-51.98])

    mac_network_1_D1R_19 = numpy.array([-52.02])

    mac_network_1_D1R_20 = numpy.array([-52.05])

    marm_network_1_D1R_0 = numpy.array([-49.67])

    marm_network_1_D1R_1 = numpy.array([-49.74])

    marm_network_1_D1R_2 = numpy.array([-49.84])

    marm_network_1_D1R_3 = numpy.array([-49.97])

    marm_network_1_D1R_4 = numpy.array([-50.12])

    marm_network_1_D1R_5 = numpy.array([-50.31])

    marm_network_1_D1R_6 = numpy.array([-50.52])

    marm_network_1_D1R_7 = numpy.array([-50.75])

    marm_network_1_D1R_8 = numpy.array([-50.98])

    marm_network_1_D1R_9 = numpy.array([-51.21])

    marm_network_1_D1R_10 = numpy.array([-51.40])

    marm_network_1_D1R_11 = numpy.array([-51.57])

    marm_network_1_D1R_12 = numpy.array([-51.71])

    marm_network_1_D1R_13 = numpy.array([-51.82])

    marm_network_1_D1R_14 = numpy.array([-51.90])

    marm_network_1_D1R_15 = numpy.array([-51.97])

    marm_network_1_D1R_16 = numpy.array([-52.01])

    marm_network_1_D1R_17 = numpy.array([-52.05])

    marm_network_1_D1R_18 = numpy.array([-52.07])

    marm_network_1_D1R_19 = numpy.array([-52.09])

    marm_network_1_D1R_20 = numpy.array([-52.10])

    # Concatenating the D1R levels for each species and Network 1
    mac_network_1_D1R_levels = numpy.vstack([mac_network_1_D1R_0, mac_network_1_D1R_1, mac_network_1_D1R_2, mac_network_1_D1R_3,
                                          mac_network_1_D1R_4, mac_network_1_D1R_5, mac_network_1_D1R_6, mac_network_1_D1R_7,
                                             mac_network_1_D1R_8, mac_network_1_D1R_9, mac_network_1_D1R_10, mac_network_1_D1R_11,
                                             mac_network_1_D1R_12, mac_network_1_D1R_13, mac_network_1_D1R_14, mac_network_1_D1R_15,
                                             mac_network_1_D1R_16, mac_network_1_D1R_17, mac_network_1_D1R_18, mac_network_1_D1R_19,
                                             mac_network_1_D1R_20])

    marm_network_1_D1R_levels = numpy.vstack([marm_network_1_D1R_0, marm_network_1_D1R_1, marm_network_1_D1R_2, marm_network_1_D1R_3,
                                              marm_network_1_D1R_4, marm_network_1_D1R_5, marm_network_1_D1R_6, marm_network_1_D1R_7,
                                              marm_network_1_D1R_8, marm_network_1_D1R_9, marm_network_1_D1R_10, marm_network_1_D1R_11,
                                              marm_network_1_D1R_12, marm_network_1_D1R_13, marm_network_1_D1R_14, marm_network_1_D1R_15,
                                              marm_network_1_D1R_16, marm_network_1_D1R_17, marm_network_1_D1R_18, marm_network_1_D1R_19,
                                              marm_network_1_D1R_20])

    # Initialize lists to store the parameter matrices
    mac_network_1_param_matrix = []
    marm_network_1_param_matrix = []

    # Create parameter matrices by appending stimuli strength to each D1R level for Macaque species, Network 1
    for d1r_level in mac_network_1_D1R_levels:
        # Append the parameter set 1000 times
        mac_network_1_param_matrix.extend([d1r_level] * 1000)

    # Convert the lists to a numpy array
    mac_network_1_param_matrix = numpy.array(mac_network_1_param_matrix)

    # Create parameter matrices by appending stimuli strength to each D1R level for Marmoset species, Network 1
    for d1r_level in marm_network_1_D1R_levels:
        # Append the parameter set 1000 times
        marm_network_1_param_matrix.extend([d1r_level] * 1000)

    # Convert the list to a numpy array
    marm_network_1_param_matrix = numpy.array(marm_network_1_param_matrix)

    simulation_params = numpy.concatenate((mac_network_1_param_matrix, marm_network_1_param_matrix))

    return simulation_params

def simulate_wm(simulation_id, v_firing_threshold_fix_tuned_inhib=-50.00):
    start_scope()  # new

    distractor_center_deg = numpy.random.choice(angles, size=175)
    stimuli = []
    stimuli_strength = 0.2 * b2.namp #0.175

    for i_angle, angle in enumerate(distractor_center_deg):
        center_idx = int(round(N_excitatory / 360. * angle))
        indices = [idx % N_excitatory for idx in range(center_idx - stim_width_idx, center_idx + stim_width_idx + 1)]
        start_time = t_distractor_start + i_angle * t_distractor_duration
        end_time = start_time + t_distractor_duration
        stimuli.append((start_time, end_time, indices))

    @network_operation(dt=500 * b2.ms)  # Log every 500 ms
    def log_progress(t):
        print(f"Simulation {simulation_id} at time {t}")

    # specify the excitatory pyramidal cells:
    Cm_excit = 0.5 * b2.nF  # membrane capacitance of excitatory neurons
    G_leak_excit = 25.0 * b2.nS  # leak conductance
    E_leak_excit = -70.0 * b2.mV  # reversal potential
    v_firing_threshold_excit = -50.0 * b2.mV  # spike condition
    v_reset_excit = -60.0 * b2.mV  # reset voltage after spike
    t_abs_refract_excit = 2.0 * b2.ms  # absolute refractory period

    # specify the inhibitory interneurons:
    Cm_inhib = 0.2 * b2.nF
    G_leak_inhib = 20.0 * b2.nS
    E_leak_inhib = -70.0 * b2.mV
    v_reset_inhib = -60.0 * b2.mV
    t_abs_refract_inhib = 1.0 * b2.ms

    v_firing_threshold_fix_tuned_inhib = v_firing_threshold_fix_tuned_inhib * b2.mV
    v_firing_threshold_tuned_inhib = -50.00 * b2.mV
    v_firing_threshold_opp_tuned_inhib = -50.00 * b2.mV

    # specify the AMPA synapses
    E_AMPA = 0.0 * b2.mV
    tau_AMPA = 2.0 * b2.ms

    # specify the GABA synapses
    E_GABA = -70.0 * b2.mV
    tau_GABA = 10.0 * b2.ms

    # specify the NMDA synapses
    E_NMDA = 0.0 * b2.mV
    tau_NMDA_s = 100.0 * b2.ms
    tau_NMDA_x = 2.0 * b2.ms
    alpha_NMDA = 0.5 * b2.kHz

    # projections from the external population
    G_extern2inhib_near = 2.38 * b2.nS
    G_extern2inhib_opp = 2.38 * b2.nS
    G_extern2excit = 3.1 * b2.nS

    # GABA-mediated projectsions from the inhibitory populations
    G_inhib2inhib = 1.024 * weight_scaling_factor * b2.nS
    GABA_scaler_E = 1.125
    G_inhib2excit = 1.336 * GABA_scaler_E * weight_scaling_factor * b2.nS

    fix_near_GABA_scaler_fix_E = 1.275 #25 #1.125 #1
    G_fix_near_inhib2fix_excit = 1.336 * fix_near_GABA_scaler_fix_E * weight_scaling_factor * b2.nS
    fix_opp_GABA_scaler_E = 0.25 #0.25 #0.125
    G_fix_opp_inhib2excit = 1.336 * fix_opp_GABA_scaler_E * weight_scaling_factor * b2.nS

    # NMDA-mediated projections from the excitatory population
    NMDA_E_scaler = 0.8032
    G_excit2excit = 0.274 * NMDA_E_scaler * weight_scaling_factor * b2.nS
    G_excit2tuned_inhib = 0.212 * weight_scaling_factor * b2.nS
    G_excit2opp_tuned_inhib = 0.212 * weight_scaling_factor * b2.nS

    # NMDA-mediated projections from the FIXATION excitatory population
    fix_NMDA_E_scaler = 1.1245 #1.2
    G_fix_excit2fix_excit = 0.274 * fix_NMDA_E_scaler * weight_scaling_factor * b2.nS
    G_fix_excit2fix_tuned_inhib = 0.212 * weight_scaling_factor * b2.nS
    G_fix_excit2fix_opp_tuned_inhib = 0.212 * weight_scaling_factor * b2.nS

    # recurrent AMPA
    AMPA_scaler_E = 1.13
    G_excit2excitA = 0.251 * AMPA_scaler_E * weight_scaling_factor * b2.nS
    GEEA = G_excit2excitA / G_extern2excit

    AMPA_tuned_I_scaler = 1.13
    G_excit2tuned_inhibA = 0.192 * AMPA_tuned_I_scaler * weight_scaling_factor * b2.nS
    GEIA = G_excit2tuned_inhibA / G_extern2inhib_near

    AMPA_opp_tuned_I_scaler = 1.13
    G_excit2opp_tuned_inhibA = 0.192 * AMPA_opp_tuned_I_scaler * weight_scaling_factor * b2.nS
    GEoppIA = G_excit2opp_tuned_inhibA / G_extern2inhib_opp

    # recurrent AMPA FIXATION
    fix_AMPA_scaler_E = 1.13 #1.2
    G_fix_excit2fix_excitA = 0.251 * fix_AMPA_scaler_E * weight_scaling_factor * b2.nS
    fix_GEEA = G_fix_excit2fix_excitA / G_extern2excit

    fix_AMPA_tuned_I_scaler = 1.13 #1.2
    G_fix_excit2tuned_inhibA = 0.192 * fix_AMPA_tuned_I_scaler * weight_scaling_factor * b2.nS
    fix_GEIA = G_fix_excit2tuned_inhibA / G_extern2inhib_near

    fix_AMPA_opp_tuned_I_scaler = 1.13 #1.2
    G_fix_excit2opp_tuned_inhibA = 0.192 * fix_AMPA_opp_tuned_I_scaler * weight_scaling_factor * b2.nS
    fix_GEoppIA = G_fix_excit2opp_tuned_inhibA / G_extern2inhib_opp

    # precompute/specify the weight profile for/in the recurrent EXCITATORY population
    tmp_excit2excit = math.sqrt(2. * math.pi) * sigma_weight_profile_E2E * erf(
        180. / math.sqrt(2.) / sigma_weight_profile_E2E) / 360.
    Jneg_excit2excit = (1. - Jpos_excit2excit * tmp_excit2excit) / (1. - tmp_excit2excit)
    presyn_excit2excit_weight_kernel = \
        [(Jneg_excit2excit + (Jpos_excit2excit - Jneg_excit2excit) *
          math.exp(-.5 * ((360. * min(j, N_excitatory - j) / N_excitatory) ** 2) / sigma_weight_profile_E2E ** 2))
         for j in range(N_excitatory)]

    # remove E-E autapses
    presyn_excit2excit_weight_kernel[0] = 0

    fft_presyn_excit2excit_weight_kernel = rfft(presyn_excit2excit_weight_kernel)

    # precompute the weight profile for the TUNED INHIBITORY recurrent population
    tmp_tuned_inhib2excit = math.sqrt(2. * math.pi) * sigma_weight_profile_I2E * erf(
        180. / math.sqrt(2.) / sigma_weight_profile_I2E) / 360.
    Jneg_tuned_inhib2excit = (1. - Jpos_inhib2excit * tmp_tuned_inhib2excit) / (1. - tmp_tuned_inhib2excit)

    # precompute the weight profile for the Excitatory to INHIBITORY recurrent populations
    tmp_excit2inhib = math.sqrt(2. * math.pi) * sigma_weight_profile_E2I * erf(
        180. / math.sqrt(2.) / sigma_weight_profile_E2I) / 360.
    Jneg_excit2inhib = (1. - Jpos_excit2inhib * tmp_excit2inhib) / (1. - tmp_excit2inhib)
    presyn_excit2inhib_weight_kernel = \
        [(Jneg_excit2inhib + (Jpos_excit2inhib - Jneg_excit2inhib) *
          math.exp(-.5 * ((360. * min(j, N_excitatory - j) / N_excitatory) ** 2) / sigma_weight_profile_E2I ** 2))
         for j in range(N_excitatory)]

    fft_presyn_excit2inhib_weight_kernel = rfft(presyn_excit2inhib_weight_kernel)

    # precompute the weight profile for the tuned inhibitory to tuned inhibitory (within pops) recurrent populations
    tmp_within_tuned_inhib2tuned_inhib = math.sqrt(2. * math.pi) * sigma_weight_profile_within_I2I * erf(
        180. / math.sqrt(2.) / sigma_weight_profile_within_I2I) / 360.
    Jneg_within_tuned_inhib2tuned_inhib = (1. - Jpos_within_inhib2inhib * tmp_within_tuned_inhib2tuned_inhib) / (
                1. - tmp_within_tuned_inhib2tuned_inhib)

    # define the tuned inhibitory population
    tuned_inhib_lif_dynamics = """
        s_NMDA_total : 1 # the post synaptic sum of s. compare with s_NMDA_presyn
        active : 1  # new parameter
        dv/dt = active * (
        - G_leak_inhib * (v-E_leak_inhib)
        - G_extern2inhib_near * s_AMPA * (v-E_AMPA)
        - G_inhib2inhib * s_GABA * (v-E_GABA)
        - G_excit2tuned_inhib * s_NMDA_total * (v-E_NMDA)/(1.0+1.0*exp(-0.062*1e3*v/volt)/3.57)
        )/Cm_inhib : volt (unless refractory)
        ds_AMPA/dt = -s_AMPA/tau_AMPA : 1
        ds_GABA/dt = -s_GABA/tau_GABA : 1
    """

    eqs_gaba = '''
    w:1
    '''

    # Tuned inhib_pop
    tuned_inhib_pop = NeuronGroup(
        N_inhibitory_per_pop, model=tuned_inhib_lif_dynamics,
        threshold="v>v_firing_threshold_tuned_inhib", reset="v=v_reset_inhib", refractory=t_abs_refract_inhib,
        method="rk2")
    # initialize with random voltages:
    tuned_inhib_pop.v = numpy.random.uniform(v_reset_inhib / b2.mV, high=v_firing_threshold_tuned_inhib / b2.mV,
                                             size=N_inhibitory_per_pop) * b2.mV

    tuned_inhib_pop.active = 1  # can remove that part while parameter search is running

    # set the connections: extern2inhib
    input_ext2tuned_inhib = PoissonInput(target=tuned_inhib_pop, target_var="s_AMPA",
                                         N=N_extern_poisson, rate=poisson_firing_rate, weight=1.0)

    # define the FIXATION tuned inhibitory population # 2 * G_inhib2inhib * s_GABA * (v-E_GABA)
    fix_tuned_inhib_lif_dynamics = """
        s_NMDA_total : 1 # the post synaptic sum of s. compare with s_NMDA_presyn
        active : 1  # new parameter
        I_AMPA = G_extern2inhib_near * s_AMPA * (v-E_AMPA): amp
        I_NMDA = G_fix_excit2fix_tuned_inhib * s_NMDA_total * (v-E_NMDA)/(1.0+1.0*exp(-0.062*1e3*v/volt)/3.57): amp
        dv/dt = active * (
        - G_leak_inhib * (v-E_leak_inhib)
        - I_AMPA
        - G_inhib2inhib * s_GABA * (v-E_GABA)
        - I_NMDA
        )/Cm_inhib : volt (unless refractory)
        ds_AMPA/dt = -s_AMPA/tau_AMPA : 1
        ds_GABA/dt = -s_GABA/tau_GABA : 1
    """

    # Tuned inhib_pop
    fix_tuned_inhib_pop = NeuronGroup(
        N_fix_inhibitory_per_pop, model=fix_tuned_inhib_lif_dynamics,
        threshold="v>v_firing_threshold_fix_tuned_inhib", reset="v=v_reset_inhib", refractory=t_abs_refract_inhib,
        method="rk2")
    # initialize with random voltages:
    fix_tuned_inhib_pop.v = numpy.random.uniform(v_reset_inhib / b2.mV, high=v_firing_threshold_fix_tuned_inhib / b2.mV,
                                                 size=N_fix_inhibitory_per_pop) * b2.mV

    fix_tuned_inhib_pop.active = 1  # can comment out this line while parameter search is running

    # set the connections: extern2inhib
    input_ext2fix_tuned_inhib = PoissonInput(target=fix_tuned_inhib_pop, target_var="s_AMPA",
                                             N=N_extern_poisson, rate=poisson_firing_rate, weight=1.0)

    # define the FIXATION oppositely tuned inhibitory population #2 * G_inhib2inhib * s_GABA * (v-E_GABA)
    fix_opp_tuned_inhib_lif_dynamics = """
        s_NMDA_total : 1 # the post synaptic sum of s. compare with s_NMDA_presyn
        active : 1  # new parameter
        I_AMPA = G_extern2inhib_opp * s_AMPA * (v-E_AMPA): amp
        I_NMDA = G_fix_excit2fix_opp_tuned_inhib * s_NMDA_total * (v-E_NMDA)/(1.0+1.0*exp(-0.062*1e3*v/volt)/3.57): amp
        dv/dt = active * (
        - G_leak_inhib * (v-E_leak_inhib)
        - I_AMPA
        - G_inhib2inhib * s_GABA * (v-E_GABA)
        - I_NMDA
        )/Cm_inhib : volt (unless refractory)
        ds_AMPA/dt = -s_AMPA/tau_AMPA : 1
        ds_GABA/dt = -s_GABA/tau_GABA : 1
    """

    # Oppositely-tuned inhib_pop
    fix_opp_tuned_inhib_pop = NeuronGroup(
        N_fix_inhibitory_per_pop, model=fix_opp_tuned_inhib_lif_dynamics,
        threshold="v>v_firing_threshold_opp_tuned_inhib", reset="v=v_reset_inhib", refractory=t_abs_refract_inhib,  # t_abs_refract_opp_inhib
        method="rk2")
    # initialize with random voltages:
    fix_opp_tuned_inhib_pop.v = numpy.random.uniform(v_reset_inhib / b2.mV, high=v_firing_threshold_opp_tuned_inhib / b2.mV,
                                                     size=N_fix_inhibitory_per_pop) * b2.mV

    fix_opp_tuned_inhib_pop.active = 1  # can comment out this line while parameter search is running

    # set the connections: extern2inhib #DO I NEED noise input on the inhibitory populations?
    input_ext2fix_opp_tuned_inhib = PoissonInput(target=fix_opp_tuned_inhib_pop, target_var="s_AMPA",
                                                 N=N_extern_poisson, rate=poisson_firing_rate, weight=1.0)

    # specify the excitatory population: # defined s_GABA : 1 (shared) BELOW
    excit_lif_dynamics = """
        I_stim : amp
        s_NMDA_total : 1 # the post synaptic sum of s. compare with s_NMDA_presyn
        dv/dt = (
        - G_leak_excit * (v-E_leak_excit)
        - G_extern2excit * s_AMPA * (v-E_AMPA)
        - G_inhib2excit * s_GABA * (v-E_GABA)
        - G_fix_opp_inhib2excit * s_fix_opp_GABA_to_E * (v-E_GABA)
        - G_excit2excit * s_NMDA_total * (v-E_NMDA)/(1.0+1.0*exp(-0.062*1e3*v/volt)/3.57)
        + I_stim
        )/Cm_excit : volt (unless refractory)
        ds_AMPA/dt = -s_AMPA/tau_AMPA : 1
        ds_GABA/dt = -s_GABA/tau_GABA : 1
        ds_fix_opp_GABA_to_E/dt = -s_fix_opp_GABA_to_E/tau_GABA : 1
        ds_NMDA/dt = -s_NMDA/tau_NMDA_s + alpha_NMDA * x * (1-s_NMDA) : 1
        dx/dt = -x/tau_NMDA_x : 1
    """

    excit_pop = NeuronGroup(N_excitatory, model=excit_lif_dynamics,
                            threshold="v>v_firing_threshold_excit", reset="v=v_reset_excit; x+=1.0",
                            refractory=t_abs_refract_excit, method="rk2")

    # initialize with random voltages:
    excit_pop.v = numpy.random.uniform(v_reset_excit / b2.mV, high=v_firing_threshold_excit / b2.mV,
                                       size=N_excitatory) * b2.mV

    excit_pop.I_stim = 0. * b2.namp

    # set the connections: extern2excit
    input_ext2excit = PoissonInput(target=excit_pop, target_var="s_AMPA",
                                   N=N_extern_poisson, rate=poisson_firing_rate, weight=1.0)

    # specify the FIXATIOn excitatory population:
    fix_excit_lif_dynamics = """
        I_stim : amp
        s_NMDA_total : 1 # the post synaptic sum of s. compare with s_NMDA_presyn
        I_AMPA = G_extern2excit * s_AMPA * (v - E_AMPA): amp
        I_NMDA = G_fix_excit2fix_excit * s_NMDA_total * (v - E_NMDA) / (1.0 + 1.0 * exp(-0.062 * 1e3 * v / volt) / 3.57): amp
        dv/dt = (
        - G_leak_excit * (v-E_leak_excit)
        - I_AMPA
        - G_fix_near_inhib2fix_excit * s_fix_near_GABA_to_fix_E * (v-E_GABA)
        - I_NMDA
        + I_stim
        )/Cm_excit : volt (unless refractory)
        ds_AMPA/dt = -s_AMPA/tau_AMPA : 1
        ds_GABA/dt = -s_GABA/tau_GABA : 1
        ds_fix_near_GABA_to_fix_E/dt = -s_fix_near_GABA_to_fix_E/tau_GABA : 1
        ds_NMDA/dt = -s_NMDA/tau_NMDA_s + alpha_NMDA * x * (1-s_NMDA) : 1
        dx/dt = -x/tau_NMDA_x : 1
    """

    fix_excit_pop = NeuronGroup(N_fix_excitatory, model=fix_excit_lif_dynamics,
                                threshold="v>v_firing_threshold_excit", reset="v=v_reset_excit; x+=1.0",
                                refractory=t_abs_refract_excit, method="rk2")

    # initialize with random voltages:
    fix_excit_pop.v = numpy.random.uniform(v_reset_excit / b2.mV, high=v_firing_threshold_excit / b2.mV,
                                           size=N_fix_excitatory) * b2.mV  # -65 * b2.mV

    fix_excit_pop.I_stim = 0. * b2.namp

    # set the connections: extern2excit
    input_ext2fix_excit = PoissonInput(target=fix_excit_pop, target_var="s_AMPA",
                                       N=N_extern_poisson, rate=poisson_firing_rate, weight=1.0)

    # Create synapses and set weights
    eqs_pre = '''
        s_GABA_post += w
        '''

    # Create synapses and set weights
    eqs_fix_pre = '''
        s_GABA_post += 1.0
        '''

    eqs_fix_opp_to_E_pre = '''
        s_fix_opp_GABA_to_E_post += 1.0
        '''

    eqs_fix_near_to_fix_E_pre = '''
        s_fix_near_GABA_to_fix_E_post += 1.0
        '''

    eqs_fix_opp_to_fix_near_pre = '''
    s_GABA_opp_to_near_post += 1.0
    '''

    # define spacing between inhibitory neurons on the ring
    spacing = N_excitatory / N_inhibitory_per_pop

    # set the connections: STRUCTURED tuned inhibitory to excitatory
    syn_tuned_inhib2excit = Synapses(tuned_inhib_pop, excit_pop, eqs_gaba, on_pre=eqs_pre)
    syn_tuned_inhib2excit.connect(p=1.0)
    syn_tuned_inhib2excit.w[
        'abs((spacing * i)-j)<N_excitatory/2'] = '(Jneg_tuned_inhib2excit + (Jpos_inhib2excit - Jneg_tuned_inhib2excit) * exp(-.5 * ((360. * abs((spacing * i)-j) / N_excitatory)) ** 2 / sigma_weight_profile_I2E ** 2))'  # 'i * 0.001'
    syn_tuned_inhib2excit.w[
        'abs((spacing * i)-j)>=N_excitatory/2'] = '(Jneg_tuned_inhib2excit + (Jpos_inhib2excit - Jneg_tuned_inhib2excit) * exp(-.5 * ((360. * (N_excitatory - abs((spacing * i)-j)) / N_excitatory)) ** 2 / sigma_weight_profile_I2E ** 2))'

    # set the connections: STRUCTURED tuned inhibitory (FIXATION) to excitatory (FIXATION)
    syn_FIX_tuned_inhib2FIX_excit = Synapses(fix_tuned_inhib_pop, fix_excit_pop, on_pre=eqs_fix_near_to_fix_E_pre)
    syn_FIX_tuned_inhib2FIX_excit.connect(p=1.0)

    # set the connections: STRUCTURED oppositely-tuned inhibitory (FIXATION) to excitatory
    syn_FIX_opp_tuned_inhib2excit = Synapses(fix_opp_tuned_inhib_pop, excit_pop, eqs_gaba, on_pre=eqs_fix_opp_to_E_pre)
    syn_FIX_opp_tuned_inhib2excit.connect(p=1.0)

    # set the connections: STRUCTURED tuned inhibitory to tuned inhibitory
    syn_tuned_inhib2tuned_inhib = Synapses(tuned_inhib_pop, tuned_inhib_pop, eqs_gaba, on_pre=eqs_pre,
                                           delay=0.0 * b2.ms)
    syn_tuned_inhib2tuned_inhib.connect(condition="i!=j", p=1.0)
    syn_tuned_inhib2tuned_inhib.w[
        'abs((spacing * i) - (spacing * j))<N_excitatory/2'] = '(Jneg_within_tuned_inhib2tuned_inhib + (Jpos_within_inhib2inhib - Jneg_within_tuned_inhib2tuned_inhib) * exp(-.5 * ((360. * abs((spacing * i) - (spacing * j)) / N_excitatory)) ** 2 / sigma_weight_profile_within_I2I ** 2))'
    syn_tuned_inhib2tuned_inhib.w[
        'abs((spacing * i) - (spacing * j))>=N_excitatory/2'] = '(Jneg_within_tuned_inhib2tuned_inhib + (Jpos_within_inhib2inhib - Jneg_within_tuned_inhib2tuned_inhib) * exp(-.5 * ((360. * (N_excitatory - abs((spacing * i) - (spacing * j))) / N_excitatory)) ** 2 / sigma_weight_profile_within_I2I ** 2))'

    # set the connections: STRUCTURED tuned inhibitory (FIXATION) to tuned inhibitory (FIXATION)
    syn_fix_tuned_inhib2fix_tuned_inhib = Synapses(fix_tuned_inhib_pop, fix_tuned_inhib_pop, eqs_gaba, on_pre=eqs_fix_pre,
                                                   delay=0.0 * b2.ms)
    syn_fix_tuned_inhib2fix_tuned_inhib.connect(condition="i!=j", p=1.0)

    # set the connections: STRUCTURED tuned inhibitory (FIXATION) to oppositely-tuned inhibitory (FIXATION)
    syn_fix_tuned_inhib2fix_opp_tuned_inhib = Synapses(fix_tuned_inhib_pop, fix_opp_tuned_inhib_pop, eqs_gaba, on_pre=eqs_fix_pre,
                                               delay=0.0 * b2.ms)
    syn_fix_tuned_inhib2fix_opp_tuned_inhib.connect(p=1.0)

    # equation for presynaptic AMPA-mediated spike
    eqs_AMPA_pre = '''
     s_AMPA_post += w
     '''

    # equation for presynaptic AMPA-mediated spike for FIXATION population
    eqs_fix_AMPA_pre = '''
     s_AMPA_post += w
     '''

    eqs_AMPA = '''
     w : 1
     '''

    syn_AMPA_excit2tuned_inhib = Synapses(excit_pop, tuned_inhib_pop, model=eqs_AMPA, on_pre=eqs_AMPA_pre)
    syn_AMPA_excit2tuned_inhib.connect(p=1.0)
    syn_AMPA_excit2tuned_inhib.w[
        'abs(i-(spacing*j))<N_excitatory/2'] = 'GEIA * (Jneg_excit2inhib + (Jpos_excit2inhib - Jneg_excit2inhib) * exp(-.5 * (360. * abs(i-(spacing*j)) / N_excitatory) ** 2 / sigma_weight_profile_E2I ** 2))'
    syn_AMPA_excit2tuned_inhib.w[
        'abs(i-(spacing*j))>=N_excitatory/2'] = 'GEIA * (Jneg_excit2inhib + (Jpos_excit2inhib - Jneg_excit2inhib) * exp(-.5 * (360. * (N_excitatory - abs(i-(spacing*j))) / N_excitatory) ** 2 / sigma_weight_profile_E2I ** 2))'

    syn_AMPA_excit2fix_tuned_inhib = Synapses(excit_pop, fix_tuned_inhib_pop, model=eqs_AMPA, on_pre=eqs_AMPA_pre)
    syn_AMPA_excit2fix_tuned_inhib.connect(p=1.0)
    syn_AMPA_excit2fix_tuned_inhib.w = GEIA

    syn_AMPA_fix_excit2fix_tuned_inhib = Synapses(fix_excit_pop, fix_tuned_inhib_pop, model=eqs_AMPA, on_pre=eqs_fix_AMPA_pre)
    syn_AMPA_fix_excit2fix_tuned_inhib.connect(p=1.0)
    syn_AMPA_fix_excit2fix_tuned_inhib.w = fix_GEIA

    syn_AMPA_fix_excit2fix_opp_tuned_inhib = Synapses(fix_excit_pop, fix_opp_tuned_inhib_pop, model=eqs_AMPA, on_pre=eqs_fix_AMPA_pre)
    syn_AMPA_fix_excit2fix_opp_tuned_inhib.connect(p=1.0)
    syn_AMPA_fix_excit2fix_opp_tuned_inhib.w = fix_GEoppIA

    syn_AMPA_excit2excit = Synapses(excit_pop, excit_pop, model=eqs_AMPA, on_pre=eqs_AMPA_pre)
    syn_AMPA_excit2excit.connect(condition="i!=j", p=1.0)
    syn_AMPA_excit2excit.w[
        'abs(i-j)<N_excitatory/2'] = 'GEEA * (Jneg_excit2excit + (Jpos_excit2excit - Jneg_excit2excit) * exp(-.5 * (360. * abs(i-j) / N_excitatory) ** 2 / sigma_weight_profile_E2E ** 2))'
    syn_AMPA_excit2excit.w[
        'abs(i-j)>=N_excitatory/2'] = 'GEEA * (Jneg_excit2excit + (Jpos_excit2excit - Jneg_excit2excit) * exp(-.5 * (360. * (N_excitatory - abs(i-j)) / N_excitatory) ** 2 / sigma_weight_profile_E2E ** 2))'

    syn_AMPA_fix_excit2fix_excit = Synapses(fix_excit_pop, fix_excit_pop, model=eqs_AMPA, on_pre=eqs_fix_AMPA_pre)
    syn_AMPA_fix_excit2fix_excit.connect(condition="i!=j", p=1.0)
    syn_AMPA_fix_excit2fix_excit.w = fix_GEEA

    # set the connections: STRUCTURED recurrent excitatory to excitatory and (tuned and opp-tuned) inhibitory
    @network_operation()
    def update_nmda_sum():
        fft_s_NMDA = rfft(excit_pop.s_NMDA)
        fft_s_NMDA_E2E_total = numpy.multiply(fft_presyn_excit2excit_weight_kernel, fft_s_NMDA)
        fft_s_NMDA_E2I_total = numpy.multiply(fft_presyn_excit2inhib_weight_kernel, fft_s_NMDA)
        s_NMDA_tot = irfft(fft_s_NMDA_E2E_total)
        s_NMDA_EI_tot = irfft(fft_s_NMDA_E2I_total)
        excit_pop.s_NMDA_total_ = s_NMDA_tot

        # set the connections: STRUCTURED NMDA-mediated excitatory to tuned inhibitory
        tuned_inhib_pop.s_NMDA_total_ = s_NMDA_EI_tot[0: -1: int(spacing)]

        s_NMDA_tot_fix = numpy.sum(fix_excit_pop.s_NMDA)
        s_NMDA_tot_fix_ex = s_NMDA_tot_fix - fix_excit_pop.s_NMDA #exclude autapses from fix_E to fix_E

        s_NMDA_tot_cue = numpy.sum(excit_pop.s_NMDA)
        fix_excit_pop.s_NMDA_total_ = s_NMDA_tot_fix_ex
        fix_tuned_inhib_pop.s_NMDA_total_ = s_NMDA_tot_fix + s_NMDA_tot_cue
        fix_opp_tuned_inhib_pop.s_NMDA_total_ = s_NMDA_tot_fix

    @network_operation(dt=1 * b2.ms)
    def stimulate_network(t):
        if (t >= 400 * b2.ms and t < 3400 * b2.ms):
            fix_excit_pop.I_stim = stimuli_strength
        else:
            fix_excit_pop.I_stim = 0. * b2.namp

        if t >= t_distractor_start and t < t_distractor_start + num_stimuli * t_distractor_duration:
            elapsed_time = t - t_distractor_start
            stimulus_index = int(elapsed_time / t_distractor_duration)
            if stimulus_index < num_stimuli:
                # Reset the input current before applying the new stimulus
                excit_pop.I_stim = 0. * b2.namp
                indices = stimuli[stimulus_index][2]
                excit_pop.I_stim[indices] = stimuli_strength
        else:
            # Ensure that no stimulus is applied outside the stimulus periods
            excit_pop.I_stim = 0. * b2.namp

    def get_monitors(pop, nr_monitored, N):
        nr_monitored = min(nr_monitored, (N))
        idx_monitored_neurons = \
            [int(math.ceil(k))
             for k in numpy.linspace(0, N - 1, nr_monitored + 2)][1:-1]
        spike_monitor = SpikeMonitor(pop, record=idx_monitored_neurons)
        return spike_monitor, idx_monitored_neurons

    # collect data of a subset of neurons:
    spike_monitor_excit, idx_monitored_neurons_excit = \
        get_monitors(excit_pop, monitored_subset_size_excit, N_excitatory)

    spike_monitor_fix_excit, idx_monitored_neurons_fix_excit = \
        get_monitors(fix_excit_pop, N_fix_excitatory, N_fix_excitatory)

    b2.run(sim_time)

    spike_indices_excit = spike_monitor_excit.i[:]  # This is a NumPy array with neuron indices
    spike_times_excit = spike_monitor_excit.t[:]

    spike_indices_fix_excit = spike_monitor_fix_excit.i[:]  # This is a NumPy array with neuron indices
    spike_times_fix_excit = spike_monitor_fix_excit.t[:]

    return spike_indices_excit, spike_times_excit, spike_indices_fix_excit, spike_times_fix_excit

def getting_started(simulation_params, simulation_id):
    start_scope()

    # Unpack simulation_params
    v_firing_threshold_fix_tuned_inhib = simulation_params

    # Use simulation_id as the seed for reproducibility
    b2.seed(simulation_id)

    b2.defaultclock.dt = 0.1 * b2.ms
    spike_indices_excit, spike_times_excit, spike_indices_fix_excit, spike_times_fix_excit = simulate_wm(simulation_id=simulation_id, v_firing_threshold_fix_tuned_inhib=v_firing_threshold_fix_tuned_inhib)

    # add the code that reduces the data here
    filename = f'/user/work/nd23721/marm_mac_figure_8/spike_monitor_data_simulation_{simulation_id}.npz'
    numpy.savez(filename,
                indices=spike_indices_excit,
                times=spike_times_excit,
                fix_indices=spike_indices_fix_excit,
                fix_times=spike_times_fix_excit,
                simulation_id=simulation_id,
                simulation_params=simulation_params)

if __name__ == "__main__":
    import sys
    from multiprocessing import Pool

    # Get the job index and offset from command-line arguments
    task_index = int(sys.argv[1])
    offset = int(sys.argv[2])

    # Adjust the task index
    task_index += offset

    # Generate simulation parameters
    simulation_params = generate_sim_params()

    # Each job runs 28 simulations
    start_index = task_index * 28
    end_index = min(start_index + 28, len(simulation_params))  # Ensure end_index doesn't exceed the size of simulation_params

    # Prepare parameter range with globally unique indices
    param_range = [(params, i + start_index) for i, params in enumerate(simulation_params[start_index:end_index])]

    # Create a multiprocessing Pool with 28 cores
    with Pool(28) as pool:
        # Run the simulation for each parallel job using the multiprocessing Pool
        pool.map(wrapper, param_range)

    # Print or log results if necessary
    print("Simulation completed for task index:", task_index)

    # OLD
    # if __name__ == "__main__":
    #     # Get the job index from command-line arguments
    #     task_index = int(sys.argv[1])
    #     offset = int(sys.argv[2])
    #
    #     # Adjust the task index
    #     task_index += offset
    #
    #     # Generate simulation parameters
    #     simulation_params = generate_sim_params()
    #
    #     # Each job runs 28 simulations
    #     start_index = task_index * 28
    #     end_index = min(start_index + 28, len(simulation_params))  # Here we ensure that end_index doesn't exceed the size of simulation_params
    #
    #     # Create a multiprocessing Pool with 28 cores
    #     pool = Pool(28)
    #
    #     # Assign the specific range of simulation parameters for each multiprocessing task
    #     param_range = [(simulation_params[i], i) for i in range(start_index, end_index)]
    #
    #     # Run the simulation for each parallel job using the multiprocessing Pool
    #     pool.starmap(getting_started, param_range)
    #
    #     # Close the Pool to free resources
    #     pool.close()
    #     pool.join()
